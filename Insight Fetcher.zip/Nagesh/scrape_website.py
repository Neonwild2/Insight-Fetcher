#!/usr/bin/env python3
"""
Fast Website Scraping Script - Quick insights from Shopify stores
"""

import requests
import json
import sys
from datetime import datetime

def scrape_website_fast(website_url):
    """Fast scrape with minimal data"""
    
    print(f"🚀 FAST SCRAPING: {website_url}")
    print("=" * 60)
    
    try:
        # Send request to a simplified endpoint (we'll create this)
        response = requests.post(
            'http://localhost:8000/fetch-insights-fast',
            json={'website_url': website_url},
            timeout=120  # 2 minutes timeout
        )
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Fast scraping completed!")
            return data
        else:
            print(f"❌ Error: {response.status_code}")
            print(f"Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {str(e)}")
        return None
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        return None

def display_fast_insights(insights):
    """Display minimal insights"""
    
    print("\n📊 QUICK INSIGHTS SUMMARY")
    print("=" * 60)
    
    print(f"🏪 Store URL: {insights.get('store_url', 'N/A')}")
    print(f"⏱️  Processing Time: {insights.get('processing_time', 'N/A')} seconds")
    
    # Products (limited)
    products = insights.get('product_catalog', [])
    print(f"\n👕 Products Found: {len(products)}")
    if products:
        print("   Sample Products:")
        for i, product in enumerate(products[:5], 1):
            price = product.get('price', 'N/A')
            print(f"   {i}. {product.get('title', 'N/A')} - {price}")
    
    # Basic store info
    print(f"\n🏪 Store Name: {insights.get('store_name', 'N/A')}")
    print(f"📱 Social Media: {len(insights.get('social_handles', []))} platforms")
    print(f"🔗 Important Links: {len(insights.get('important_links', []))}")

def save_to_file(insights, filename=None):
    """Save insights to a JSON file"""
    
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        store_name = insights.get('store_url', 'unknown').replace('https://', '').replace('http://', '').replace('/', '_')
        filename = f"fast_insights_{store_name}_{timestamp}.json"
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(insights, f, indent=2, ensure_ascii=False, default=str)
        print(f"\n💾 Fast insights saved to: {filename}")
        return filename
    except Exception as e:
        print(f"❌ Error saving file: {str(e)}")
        return None

def main():
    """Main function"""
    
    print("⚡ FAST WEBSITE INSIGHTS SCRAPER")
    print("=" * 60)
    
    # Get website URL from user
    if len(sys.argv) > 1:
        website_url = sys.argv[1]
    else:
        website_url = input("Enter website URL to scrape: ").strip()
    
    if not website_url:
        print("❌ No website URL provided")
        return
    
    # Add http:// if not present
    if not website_url.startswith(('http://', 'https://')):
        website_url = 'https://' + website_url
    
    # Fast scrape the website
    insights = scrape_website_fast(website_url)
    
    if insights:
        # Display insights
        display_fast_insights(insights)
        
        # Ask if user wants to save
        save_choice = input("\n💾 Save insights to file? (y/n): ").lower().strip()
        if save_choice in ['y', 'yes']:
            filename = save_to_file(insights)
            if filename:
                print(f"📁 File saved: {filename}")
        
        print("\n🎉 Fast scraping completed!")
        
    else:
        print("\n❌ Failed to scrape website")

if __name__ == "__main__":
    main()
