#!/usr/bin/env python3
"""
Test script to verify updated Pydantic models
"""

from src.models.shopify_insights import (
    ShopifyInsightsResponse, Product, FAQ, SocialHandle, ImportantLink
)

def test_models():
    """Test the updated Pydantic models"""
    
    print("🧪 Testing Updated Pydantic Models")
    print("=" * 50)
    
    try:
        # Test Product model with flexible data
        product = Product(
            title="Blue Cotton Abstract Co-ord Set",
            description="A beautiful co-ord set",
            price=699.0,
            currency="INR",
            category="coord_set",  # This should work now
            tags=["cotton", "abstract"],
            url="https://memy.co.in/product/coord-set",
            available=True,
            variants={},  # This should work now (dict instead of list)
            metafields={},
            images=[]
        )
        print("✅ Product model validation passed")
        print(f"   - Title: {product.title}")
        print(f"   - Category: {product.category}")
        print(f"   - Variants type: {type(product.variants)}")
        
        # Test FAQ model
        faq = FAQ(
            question="What is your return policy?",
            answer="30 days return policy",
            category="returns"
        )
        print("✅ FAQ model validation passed")
        
        # Test SocialHandle model
        social = SocialHandle(
            platform="facebook",
            url="https://facebook.com/memy",
            handle=None  # This should work now
        )
        print("✅ SocialHandle model validation passed")
        
        # Test ImportantLink model
        link = ImportantLink(
            title="About Us",
            url="https://memy.co.in/about",
            description="Learn about our company",
            category="company"  # This should work now
        )
        print("✅ ImportantLink model validation passed")
        
        # Test main response model
        response = ShopifyInsightsResponse(
            store_url="https://memy.co.in",
            product_catalog=[product],
            hero_products=[],
            faqs=[faq],
            social_handles=[social],
            important_links=[link],
            processing_time=64.0  # This should work now
        )
        print("✅ ShopifyInsightsResponse model validation passed")
        print(f"   - Store URL: {response.store_url}")
        print(f"   - Products: {len(response.product_catalog)}")
        print(f"   - Processing time: {response.processing_time}")
        
        print("\n🎉 All model validations passed! The data should now save to the database.")
        
    except Exception as e:
        print(f"❌ Model validation failed: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_models()
