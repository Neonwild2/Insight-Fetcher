#!/usr/bin/env python3
"""
Test script to debug database saving
"""

import asyncio
import os
from src.services.database_service import DatabaseService
from src.models.shopify_insights import ShopifyInsightsResponse, Product, FAQ, SocialHandle, ImportantLink

# Set environment variable
os.environ['DATABASE_URL'] = 'mysql://root:Qwerty@123@localhost/shopify_insights'

async def test_database_save():
    """Test database saving functionality"""
    
    print("🧪 Testing Database Save Functionality")
    print("=" * 50)
    
    try:
        # Create a test insights object with correct data structure
        test_insights = ShopifyInsightsResponse(
            store_url="https://test-store.myshopify.com",
            product_catalog=[
                Product(
                    title="Test Product",
                    description="A test product description",
                    price=29.99,
                    currency="USD",
                    category="clothing",  # Use valid category
                    tags=["test", "demo"],
                    url="https://test.com/product",
                    available=True,
                    variants={},  # Now accepts dict
                    metafields={},
                    images=[]
                )
            ],
            hero_products=[],
            privacy_policy=None,
            return_policy=None,
            refund_policy=None,
            faqs=[
                FAQ(
                    question="What is this?",
                    answer="This is a test FAQ",
                    category="general"
                )
            ],
            social_handles=[
                SocialHandle(
                    platform="facebook",
                    url="https://facebook.com/test",
                    handle="@teststore"
                )
            ],
            contact_info=None,
            brand_context=None,
            important_links=[
                ImportantLink(
                    title="About Us",
                    url="https://test.com/about",
                    category="company",
                    description="Learn about our company"
                )
            ],
            processing_time=1.5
        )
        
        print("✅ Created test insights object")
        print(f"   - Store URL: {test_insights.store_url}")
        print(f"   - Products: {len(test_insights.product_catalog)}")
        print(f"   - FAQs: {len(test_insights.faqs)}")
        print(f"   - Social handles: {len(test_insights.social_handles)}")
        print(f"   - Important links: {len(test_insights.important_links)}")
        
        # Initialize database service
        print("\n🔧 Initializing database service...")
        db_service = DatabaseService()
        
        # Try to save
        print("💾 Attempting to save to database...")
        success = await db_service.save_store_insights(test_insights)
        
        if success:
            print("✅ Successfully saved to database!")
        else:
            print("❌ Failed to save to database")
        
        # Cleanup
        db_service.close()
        
    except Exception as e:
        print(f"❌ Error during test: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_database_save())
