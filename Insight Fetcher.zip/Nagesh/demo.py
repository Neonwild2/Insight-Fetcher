#!/usr/bin/env python3
"""
Demo script for Shopify Store Insights Fetcher
"""

import asyncio
import json
import sys
from pathlib import Path

# Add src to Python path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

async def demo_shopify_insights():
    """Demo the Shopify insights functionality"""
    
    print("🔍 Shopify Store Insights Fetcher - Demo")
    print("=" * 50)
    
    try:
        # Import the service
        from src.services.shopify_insights_service import ShopifyInsightsService
        
        # Initialize the service
        service = ShopifyInsightsService()
        
        # Example Shopify store URLs for demo
        demo_urls = [
            "https://memy.co.in",
            "https://hairoriginals.com"
        ]
        
        print(f"📋 Demo URLs: {', '.join(demo_urls)}")
        print("\n⚠️  Note: This is a demo. In a real scenario, you would:")
        print("   1. Have proper database setup")
        print("   2. Configure environment variables")
        print("   3. Have Chrome/Chromium installed")
        print("   4. Respect website terms of service")
        
        print("\n🚀 Starting demo...")
        
        # Try to fetch insights for the first demo URL
        demo_url = demo_urls[0]
        print(f"\n🔍 Fetching insights for: {demo_url}")
        
        try:
            # This will likely fail without proper setup, but shows the structure
            insights = await service.fetch_store_insights(demo_url)
            print("✅ Successfully fetched insights!")
            print(f"📊 Found {len(insights.product_catalog)} products")
            print(f"❓ Found {len(insights.faqs)} FAQs")
            print(f"📱 Found {len(insights.social_handles)} social handles")
            
        except Exception as e:
            print(f"❌ Demo failed (expected without proper setup): {str(e)}")
            print("\n💡 To run the full demo:")
            print("   1. Install dependencies: pip install -r requirements.txt")
            print("   2. Set up MySQL database")
            print("   3. Configure .env file")
            print("   4. Install Chrome/Chromium")
            print("   5. Run: python start.py")
        
        # Clean up
        await service.close()
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Make sure you have installed all dependencies:")
        print("   pip install -r requirements.txt")
    except Exception as e:
        print(f"❌ Demo error: {e}")

def demo_api_structure():
    """Demo the API structure"""
    
    print("\n" + "=" * 50)
    print("📚 API Structure Demo")
    print("=" * 50)
    
    # Example API request
    api_request = {
        "website_url": "https://example-store.myshopify.com"
    }
    
    print("📤 Example API Request:")
    print(f"POST /fetch-insights")
    print(f"Content-Type: application/json")
    print(json.dumps(api_request, indent=2))
    
    # Example API response structure
    api_response = {
        "store_url": "https://example-store.myshopify.com",
        "timestamp": "2024-01-15T10:30:00Z",
        "success": True,
        "product_catalog": [
            {
                "title": "Example Product",
                "description": "Product description",
                "price": 29.99,
                "currency": "USD",
                "category": "clothing"
            }
        ],
        "total_products": 1,
        "processing_time": 5.2
    }
    
    print("\n📥 Example API Response Structure:")
    print(json.dumps(api_response, indent=2))
    
    print("\n🔗 Available Endpoints:")
    print("   GET  /              - API information")
    print("   GET  /health        - Health check")
    print("   POST /fetch-insights - Fetch store insights")

def main():
    """Main demo function"""
    print("🎯 Shopify Store Insights Fetcher - Complete Demo")
    print("=" * 60)
    
    # Run API structure demo
    demo_api_structure()
    
    # Run async insights demo
    try:
        asyncio.run(demo_shopify_insights())
    except Exception as e:
        print(f"\n❌ Async demo failed: {e}")
    
    print("\n" + "=" * 60)
    print("🎉 Demo completed!")
    print("\n📖 For more information:")
    print("   - Read the README.md file")
    print("   - Check the API docs at http://localhost:8000/docs")
    print("   - Review the source code in src/ directory")

if __name__ == "__main__":
    main()
