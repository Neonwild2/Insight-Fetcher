#!/usr/bin/env python3
"""
Database Viewer - View all scraped insights from the database
"""

import mysql.connector
from datetime import datetime
import json

def connect_database():
    """Connect to MySQL database"""
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Qwerty@123",
            database="shopify_insights"
        )
        return connection
    except Exception as e:
        print(f"❌ Database connection failed: {str(e)}")
        return None

def view_all_stores():
    """View all scraped stores"""
    
    print("🏪 ALL SCRAPED STORES")
    print("=" * 60)
    
    connection = connect_database()
    if not connection:
        return
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Get all stores
        cursor.execute("""
            SELECT s.*, 
                   COUNT(DISTINCT p.id) as product_count,
                   COUNT(DISTINCT f.id) as faq_count,
                   COUNT(DISTINCT sh.id) as social_count,
                   COUNT(DISTINCT il.id) as link_count
            FROM stores s
            LEFT JOIN store_insights si ON s.id = si.store_id
            LEFT JOIN products p ON s.id = p.store_id
            LEFT JOIN faqs f ON si.id = f.insights_id
            LEFT JOIN social_handles sh ON si.id = sh.insights_id
            LEFT JOIN important_links il ON si.id = il.insights_id
            GROUP BY s.id
            ORDER BY s.created_at DESC
        """)
        
        stores = cursor.fetchall()
        
        if not stores:
            print("No stores found in database")
            return
        
        for i, store in enumerate(stores, 1):
            print(f"\n{i}. {store['store_name']}")
            print(f"   URL: {store['store_url']}")
            print(f"   Created: {store['created_at']}")
            print(f"   📊 Data Summary:")
            print(f"      - Products: {store['product_count']}")
            print(f"      - FAQs: {store['faq_count']}")
            print(f"      - Social Media: {store['social_count']}")
            print(f"      - Important Links: {store['link_count']}")
            
    except Exception as e:
        print(f"❌ Error viewing stores: {str(e)}")
    finally:
        connection.close()

def view_store_details(store_id):
    """View detailed information for a specific store"""
    
    print(f"\n🔍 STORE DETAILS - ID: {store_id}")
    print("=" * 60)
    
    connection = connect_database()
    if not connection:
        return
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Get store info
        cursor.execute("SELECT * FROM stores WHERE id = %s", (store_id,))
        store = cursor.fetchone()
        
        if not store:
            print(f"Store with ID {store_id} not found")
            return
        
        print(f"🏪 Store: {store['store_name']}")
        print(f"🌐 URL: {store['store_url']}")
        print(f"📅 Created: {store['created_at']}")
        
        # Get products
        cursor.execute("SELECT * FROM products WHERE store_id = %s ORDER BY title", (store_id,))
        products = cursor.fetchall()
        
        print(f"\n👕 Products ({len(products)}):")
        for product in products:
            price = product['price'] if product['price'] else 'N/A'
            currency = product['currency'] if product['currency'] else 'USD'
            print(f"   - {product['title']} - {price} {currency}")
        
        # Get FAQs
        cursor.execute("""
            SELECT f.* FROM faqs f
            JOIN store_insights si ON f.insights_id = si.id
            WHERE si.store_id = %s
        """, (store_id,))
        faqs = cursor.fetchall()
        
        print(f"\n❓ FAQs ({len(faqs)}):")
        for faq in faqs:
            print(f"   Q: {faq['question']}")
            print(f"   A: {faq['answer'][:100]}...")
            print()
        
        # Get social handles
        cursor.execute("""
            SELECT sh.* FROM social_handles sh
            JOIN store_insights si ON sh.insights_id = si.id
            WHERE si.store_id = %s
        """, (store_id,))
        social = cursor.fetchall()
        
        print(f"\n📱 Social Media ({len(social)}):")
        for platform in social:
            print(f"   - {platform['platform']}: {platform['url']}")
        
        # Get important links
        cursor.execute("""
            SELECT il.* FROM important_links il
            JOIN store_insights si ON il.insights_id = si.id
            WHERE si.store_id = %s
        """, (store_id,))
        links = cursor.fetchall()
        
        print(f"\n🔗 Important Links ({len(links)}):")
        for link in links:
            print(f"   - {link['title']}: {link['url']}")
            
    except Exception as e:
        print(f"❌ Error viewing store details: {str(e)}")
    finally:
        connection.close()

def export_store_data(store_id, filename=None):
    """Export store data to JSON file"""
    
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"store_{store_id}_export_{timestamp}.json"
    
    connection = connect_database()
    if not connection:
        return None
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Get all store data
        store_data = {}
        
        # Store info
        cursor.execute("SELECT * FROM stores WHERE id = %s", (store_id,))
        store = cursor.fetchone()
        if store:
            store_data['store'] = store
            
            # Products
            cursor.execute("SELECT * FROM products WHERE store_id = %s", (store_id,))
            store_data['products'] = cursor.fetchall()
            
            # FAQs
            cursor.execute("""
                SELECT f.* FROM faqs f
                JOIN store_insights si ON f.insights_id = si.id
                WHERE si.store_id = %s
            """, (store_id,))
            store_data['faqs'] = cursor.fetchall()
            
            # Social handles
            cursor.execute("""
                SELECT sh.* FROM social_handles sh
                JOIN store_insights si ON sh.insights_id = si.id
                WHERE si.store_id = %s
            """, (store_id,))
            store_data['social_handles'] = cursor.fetchall()
            
            # Important links
            cursor.execute("""
                SELECT il.* FROM important_links il
                JOIN store_insights si ON il.insights_id = si.id
                WHERE si.store_id = %s
            """, (store_id,))
            store_data['important_links'] = cursor.fetchall()
            
            # Store insights
            cursor.execute("SELECT * FROM store_insights WHERE store_id = %s", (store_id,))
            store_data['store_insights'] = cursor.fetchall()
        
        # Save to file
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(store_data, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"💾 Data exported to: {filename}")
        return filename
        
    except Exception as e:
        print(f"❌ Error exporting data: {str(e)}")
        return None
    finally:
        connection.close()

def main():
    """Main function"""
    
    print("🗄️  DATABASE VIEWER - SHOPIFY INSIGHTS")
    print("=" * 60)
    
    while True:
        print("\n📋 Choose an option:")
        print("1. View all stores")
        print("2. View store details")
        print("3. Export store data")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            view_all_stores()
            
        elif choice == '2':
            store_id = input("Enter store ID: ").strip()
            try:
                view_store_details(int(store_id))
            except ValueError:
                print("❌ Invalid store ID")
                
        elif choice == '3':
            store_id = input("Enter store ID: ").strip()
            try:
                export_store_data(int(store_id))
            except ValueError:
                print("❌ Invalid store ID")
                
        elif choice == '4':
            print("👋 Goodbye!")
            break
            
        else:
            print("❌ Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
