import asyncio
import time
import logging
from typing import List, Optional, Dict, Any
from urllib.parse import urljoin, urlparse
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

from src.models.shopify_insights import (
    ShopifyInsightsResponse, Product, Policy, FAQ, SocialHandle, 
    ContactInfo, BrandContext, ImportantLink
)
from src.services.scrapers.product_scraper import ProductScraper
from src.services.scrapers.policy_scraper import PolicyScraper
from src.services.scrapers.faq_scraper import FAQScraper
from src.services.scrapers.social_scraper import SocialScraper
from src.services.scrapers.contact_scraper import ContactScraper
from src.services.scrapers.brand_scraper import BrandScraper
from src.services.scrapers.link_scraper import LinkScraper
from src.services.llm_processor import LLMProcessor
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class ShopifyInsightsService:
    """Main service for fetching Shopify store insights"""
    
    def __init__(self):
        self.settings = get_settings()
        self.product_scraper = ProductScraper()
        self.policy_scraper = PolicyScraper()
        self.faq_scraper = FAQScraper()
        self.social_scraper = SocialScraper()
        self.contact_scraper = ContactScraper()
        self.brand_scraper = BrandScraper()
        self.link_scraper = LinkScraper()
        self.llm_processor = LLMProcessor()
        
        # Initialize webdriver for JavaScript-heavy pages
        self.driver = None
        
    async def fetch_store_insights(self, website_url: str) -> ShopifyInsightsResponse:
        """
        Fetch comprehensive insights from a Shopify store
        
        Args:
            website_url: URL of the Shopify store
            
        Returns:
            ShopifyInsightsResponse: Structured insights data
        """
        start_time = time.time()
        
        try:
            # Normalize URL
            website_url = self._normalize_url(website_url)
            logger.info(f"Starting insights fetch for: {website_url}")
            
            # Initialize webdriver if needed
            if not self.driver:
                self.driver = self._init_webdriver()
            
            # Fetch all insights concurrently
            tasks = [
                self._fetch_products(website_url),
                self._fetch_policies(website_url),
                self._fetch_faqs(website_url),
                self._fetch_social_handles(website_url),
                self._fetch_contact_info(website_url),
                self._fetch_brand_context(website_url),
                self._fetch_important_links(website_url)
            ]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            products, hero_products = results[0] if not isinstance(results[0], Exception) else ([], [])
            policies = results[1] if not isinstance(results[1], Exception) else {}
            faqs = results[2] if not isinstance(results[2], Exception) else []
            social_handles = results[3] if not isinstance(results[3], Exception) else []
            contact_info = results[4] if not isinstance(results[4], Exception) else None
            brand_context = results[5] if not isinstance(results[5], Exception) else None
            important_links = results[6] if not isinstance(results[6], Exception) else []
            
            # Create response
            processing_time = time.time() - start_time
            response = ShopifyInsightsResponse(
                store_url=website_url,
                product_catalog=products,
                hero_products=hero_products,
                privacy_policy=policies.get('privacy'),
                return_policy=policies.get('return'),
                refund_policy=policies.get('refund'),
                faqs=faqs,
                social_handles=social_handles,
                contact_info=contact_info,
                brand_context=brand_context,
                important_links=important_links,
                total_products=len(products),
                total_faqs=len(faqs),
                processing_time=processing_time
            )
            
            logger.info(f"Successfully fetched insights for {website_url} in {processing_time:.2f}s")
            return response
            
        except Exception as e:
            logger.error(f"Error fetching insights for {website_url}: {str(e)}")
            raise
        finally:
            # Clean up webdriver
            if self.driver:
                self.driver.quit()
                self.driver = None
    
    async def _fetch_products(self, website_url: str) -> tuple[List[Product], List[Product]]:
        """Fetch product catalog and hero products"""
        try:
            products = await self.product_scraper.scrape_products(website_url)
            hero_products = await self.product_scraper.scrape_hero_products(website_url, self.driver)
            return products, hero_products
        except Exception as e:
            logger.error(f"Error fetching products: {str(e)}")
            return [], []
    
    async def _fetch_policies(self, website_url: str) -> Dict[str, Policy]:
        """Fetch store policies"""
        try:
            return await self.policy_scraper.scrape_policies(website_url, self.driver)
        except Exception as e:
            logger.error(f"Error fetching policies: {str(e)}")
            return {}
    
    async def _fetch_faqs(self, website_url: str) -> List[FAQ]:
        """Fetch store FAQs"""
        try:
            return await self.faq_scraper.scrape_faqs(website_url, self.driver)
        except Exception as e:
            logger.error(f"Error fetching FAQs: {str(e)}")
            return []
    
    async def _fetch_social_handles(self, website_url: str) -> List[SocialHandle]:
        """Fetch social media handles"""
        try:
            return await self.social_scraper.scrape_social_handles(website_url, self.driver)
        except Exception as e:
            logger.error(f"Error fetching social handles: {str(e)}")
            return []
    
    async def _fetch_contact_info(self, website_url: str) -> Optional[ContactInfo]:
        """Fetch contact information"""
        try:
            return await self.contact_scraper.scrape_contact_info(website_url, self.driver)
        except Exception as e:
            logger.error(f"Error fetching contact info: {str(e)}")
            return None
    
    async def _fetch_brand_context(self, website_url: str) -> Optional[BrandContext]:
        """Fetch brand context and information"""
        try:
            return await self.brand_scraper.scrape_brand_context(website_url, self.driver)
        except Exception as e:
            logger.error(f"Error fetching brand context: {str(e)}")
            return None
    
    async def _fetch_important_links(self, website_url: str) -> List[ImportantLink]:
        """Fetch important links"""
        try:
            return await self.link_scraper.scrape_important_links(website_url, self.driver)
        except Exception as e:
            logger.error(f"Error fetching important links: {str(e)}")
            return []
    
    def _normalize_url(self, url: str) -> str:
        """Normalize URL format"""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        return url.rstrip('/')
    
    def _init_webdriver(self) -> webdriver.Chrome:
        """Initialize Chrome webdriver"""
        try:
            chrome_options = Options()
            if self.settings.headless_browser:
                chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")
            
            driver = webdriver.Chrome(
                service=webdriver.chrome.service.Service(ChromeDriverManager().install()),
                options=chrome_options
            )
            driver.set_page_load_timeout(self.settings.browser_timeout)
            return driver
        except Exception as e:
            logger.error(f"Error initializing webdriver: {str(e)}")
            raise
    
    async def close(self):
        """Clean up resources"""
        if self.driver:
            self.driver.quit()
            self.driver = None
