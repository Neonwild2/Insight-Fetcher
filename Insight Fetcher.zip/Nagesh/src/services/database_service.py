import logging
from typing import List, Optional
from datetime import datetime

from src.database.connection import get_db_session
from src.database.models import (
    Store, StoreInsights, Product, FAQ, SocialHandle, 
    ImportantLink, Competitor, AnalysisLog
)
from src.models.shopify_insights import (
    ShopifyInsightsResponse, Product as ProductModel, 
    FAQ as FAQModel, SocialHandle as SocialHandleModel,
    ImportantLink as ImportantLinkModel
)

logger = logging.getLogger(__name__)

class DatabaseService:
    """Service for saving scraped insights to the database"""
    
    def __init__(self):
        self.db = None
    
    def _get_db(self):
        """Lazy load database session"""
        if self.db is None:
            self.db = get_db_session()
        return self.db
    
    async def save_store_insights(self, insights: ShopifyInsightsResponse) -> bool:
        """
        Save complete store insights to the database
        
        Args:
            insights: ShopifyInsightsResponse object containing all scraped data
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Create or update store record
            store = await self._get_or_create_store(insights.store_url)
            
            # Create store insights record
            store_insights = await self._create_store_insights(store.id, insights)
            
            # Save products
            if insights.product_catalog:
                await self._save_products(store.id, insights.product_catalog)
            
            # Save hero products
            if insights.hero_products:
                await self._save_hero_products(store.id, insights.hero_products)
            
            # Save FAQs
            if insights.faqs:
                await self._save_faqs(store_insights.id, insights.faqs)
            
            # Save social handles
            if insights.social_handles:
                await self._save_social_handles(store_insights.id, insights.social_handles)
            
            # Save important links
            if insights.important_links:
                await self._save_important_links(store_insights.id, insights.important_links)
            
            # Log the analysis
            await self._log_analysis(store.id, True, insights.processing_time)
            
            logger.info(f"Successfully saved insights for store: {insights.store_url}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving insights to database: {str(e)}")
            # Log failed analysis
            try:
                store = await self._get_or_create_store(insights.store_url)
                await self._log_analysis(store.id, False, 0)
            except:
                pass
            return False
    
    async def _get_or_create_store(self, store_url: str) -> Store:
        """Get existing store or create new one"""
        try:
            db = self._get_db()
            # Try to find existing store
            store = db.query(Store).filter(Store.store_url == store_url).first()
            
            if not store:
                # Create new store
                store = Store(
                    store_url=store_url,
                    store_name=store_url.split('//')[1].split('/')[0] if '//' in store_url else store_url
                )
                db.add(store)
                db.commit()
                db.refresh(store)
                logger.info(f"Created new store: {store_url}")
            else:
                logger.info(f"Found existing store: {store_url}")
            
            return store
            
        except Exception as e:
            logger.error(f"Error in _get_or_create_store: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _create_store_insights(self, store_id: int, insights: ShopifyInsightsResponse) -> StoreInsights:
        """Create store insights record"""
        try:
            db = self._get_db()
            store_insights = StoreInsights(
                store_id=store_id,
                timestamp=datetime.utcnow(),
                success=True,
                processing_time=insights.processing_time,
                total_products=len(insights.product_catalog) if insights.product_catalog else 0,
                total_faqs=len(insights.faqs) if insights.faqs else 0
            )
            
            db.add(store_insights)
            db.commit()
            db.refresh(store_insights)
            
            return store_insights
            
        except Exception as e:
            logger.error(f"Error in _create_store_insights: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _save_products(self, store_id: int, products: List[ProductModel]):
        """Save products to database"""
        try:
            db = self._get_db()
            for product_data in products:
                product = Product(
                    store_id=store_id,
                    title=product_data.title,
                    description=product_data.description,
                    price=product_data.price,
                    currency=product_data.currency,
                    category=product_data.category,
                    tags=product_data.tags,
                    url=product_data.url,
                    available=product_data.available,
                    variants=product_data.variants,
                    metafields=product_data.metafields,
                    images=product_data.images,
                    is_hero_product=False
                )
                db.add(product)
            
            db.commit()
            logger.info(f"Saved {len(products)} products")
            
        except Exception as e:
            logger.error(f"Error saving products: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _save_hero_products(self, store_id: int, hero_products: List[ProductModel]):
        """Save hero products to database"""
        try:
            db = self._get_db()
            for product_data in hero_products:
                product = Product(
                    store_id=store_id,
                    title=product_data.title,
                    description=product_data.description,
                    price=product_data.price,
                    currency=product_data.currency,
                    category=product_data.category,
                    tags=product_data.tags,
                    url=product_data.url,
                    available=product_data.available,
                    variants=product_data.variants,
                    metafields=product_data.metafields,
                    images=product_data.images,
                    is_hero_product=True
                )
                db.add(product)
            
            db.commit()
            logger.info(f"Saved {len(hero_products)} hero products")
            
        except Exception as e:
            logger.error(f"Error saving hero products: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _save_faqs(self, insights_id: int, faqs: List[FAQModel]):
        """Save FAQs to database"""
        try:
            db = self._get_db()
            for faq_data in faqs:
                faq = FAQ(
                    insights_id=insights_id,
                    question=faq_data.question,
                    answer=faq_data.answer,
                    category=faq_data.category
                )
                db.add(faq)
            
            db.commit()
            logger.info(f"Saved {len(faqs)} FAQs")
            
        except Exception as e:
            logger.error(f"Error saving FAQs: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _save_social_handles(self, insights_id: int, social_handles: List[SocialHandleModel]):
        """Save social handles to database"""
        try:
            db = self._get_db()
            for social_data in social_handles:
                social = SocialHandle(
                    insights_id=insights_id,
                    platform=social_data.platform,
                    url=social_data.url,
                    handle=social_data.handle
                )
                db.add(social)
            
            db.commit()
            logger.info(f"Saved {len(social_handles)} social handles")
            
        except Exception as e:
            logger.error(f"Error saving social handles: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _save_important_links(self, insights_id: int, important_links: List[ImportantLinkModel]):
        """Save important links to database"""
        try:
            db = self._get_db()
            for link_data in important_links:
                link = ImportantLink(
                    insights_id=insights_id,
                    title=link_data.title,
                    url=link_data.url,
                    link_type=link_data.category,  # Use link_type instead of category
                    description=link_data.description
                )
                db.add(link)
            
            db.commit()
            logger.info(f"Saved {len(important_links)} important links")
            
        except Exception as e:
            logger.error(f"Error saving important links: {str(e)}")
            if self.db:
                self.db.rollback()
            raise
    
    async def _log_analysis(self, store_id: int, success: bool, processing_time: float):
        """Log analysis activity"""
        try:
            db = self._get_db()
            log = AnalysisLog(
                store_url=f"store_{store_id}",  # Use store_url instead of store_id
                analysis_type="initial",
                status="success" if success else "failed",
                processing_time=processing_time,
                created_at=datetime.utcnow()
            )
            db.add(log)
            db.commit()
            
        except Exception as e:
            logger.error(f"Error logging analysis: {str(e)}")
            if self.db:
                self.db.rollback()
    
    def close(self):
        """Close database connection"""
        if self.db:
            self.db.close()
            self.db = None
