import logging
import json
from typing import Dict, Any, Optional, List
import openai
from openai import AsyncOpenAI

from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class LLMProcessor:
    """Service for processing data using LLMs (OpenAI)"""
    
    def __init__(self):
        self.settings = get_settings()
        self.client = None
        
        # Initialize OpenAI client if API key is available
        if self.settings.openai_api_key:
            try:
                self.client = AsyncOpenAI(api_key=self.settings.openai_api_key)
                logger.info("OpenAI client initialized successfully")
            except Exception as e:
                logger.warning(f"Failed to initialize OpenAI client: {str(e)}")
        else:
            logger.info("OpenAI API key not provided, LLM processing disabled")
    
    async def process_and_structure_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process and structure raw scraped data using LLM
        
        Args:
            raw_data: Raw scraped data from the store
            
        Returns:
            Dict[str, Any]: Processed and structured data
        """
        if not self.client:
            logger.warning("LLM processing not available, returning raw data")
            return raw_data
        
        try:
            # Create a prompt for the LLM
            prompt = self._create_processing_prompt(raw_data)
            
            # Process with OpenAI
            response = await self._process_with_openai(prompt)
            
            if response:
                # Parse and return the structured response
                return self._parse_llm_response(response)
            else:
                return raw_data
                
        except Exception as e:
            logger.error(f"Error processing data with LLM: {str(e)}")
            return raw_data
    
    async def enhance_product_descriptions(self, products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Enhance product descriptions using LLM
        
        Args:
            products: List of product data
            
        Returns:
            List[Dict[str, Any]]: Enhanced product data
        """
        if not self.client or not products:
            return products
        
        try:
            enhanced_products = []
            
            for product in products[:10]:  # Limit to 10 products for cost efficiency
                try:
                    enhanced_product = await self._enhance_single_product(product)
                    enhanced_products.append(enhanced_product)
                except Exception as e:
                    logger.debug(f"Error enhancing product {product.get('title', 'Unknown')}: {str(e)}")
                    enhanced_products.append(product)
                    continue
            
            # Add remaining products without enhancement
            enhanced_products.extend(products[10:])
            
            return enhanced_products
            
        except Exception as e:
            logger.error(f"Error enhancing product descriptions: {str(e)}")
            return products
    
    async def categorize_products(self, products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Categorize products using LLM
        
        Args:
            products: List of product data
            
        Returns:
            List[Dict[str, Any]]: Categorized product data
        """
        if not self.client or not products:
            return products
        
        try:
            # Create categorization prompt
            prompt = self._create_categorization_prompt(products)
            
            # Process with OpenAI
            response = await self._process_with_openai(prompt)
            
            if response:
                # Parse categorization response
                categorized_products = self._parse_categorization_response(response, products)
                return categorized_products
            else:
                return products
                
        except Exception as e:
            logger.error(f"Error categorizing products with LLM: {str(e)}")
            return products
    
    async def generate_brand_summary(self, brand_data: Dict[str, Any]) -> Optional[str]:
        """
        Generate a brand summary using LLM
        
        Args:
            brand_data: Brand context data
            
        Returns:
            Optional[str]: Generated brand summary
        """
        if not self.client or not brand_data:
            return None
        
        try:
            # Create summary prompt
            prompt = self._create_summary_prompt(brand_data)
            
            # Process with OpenAI
            response = await self._process_with_openai(prompt)
            
            if response:
                return self._extract_summary_from_response(response)
            else:
                return None
                
        except Exception as e:
            logger.error(f"Error generating brand summary with LLM: {str(e)}")
            return None
    
    def _create_processing_prompt(self, raw_data: Dict[str, Any]) -> str:
        """Create a prompt for processing raw data"""
        prompt = f"""
        You are a data processing expert. Please analyze and structure the following Shopify store data to make it more organized and readable.
        
        Raw data:
        {json.dumps(raw_data, indent=2)}
        
        Please:
        1. Clean and format the data
        2. Remove any duplicate or irrelevant information
        3. Organize information logically
        4. Ensure consistent formatting
        5. Add any missing context where appropriate
        
        Return the processed data in valid JSON format.
        """
        return prompt
    
    def _create_categorization_prompt(self, products: List[Dict[str, Any]]) -> str:
        """Create a prompt for categorizing products"""
        product_summaries = []
        for product in products[:20]:  # Limit to 20 products for prompt length
            summary = f"Title: {product.get('title', 'N/A')}, Description: {product.get('description', 'N/A')[:100]}..."
            product_summaries.append(summary)
        
        prompt = f"""
        You are a product categorization expert. Please categorize the following products into appropriate categories.
        
        Products:
        {chr(10).join(product_summaries)}
        
        Please categorize each product into one of these categories:
        - Clothing
        - Electronics
        - Beauty
        - Home
        - Sports
        - Food
        - Other
        
        Return the categorization in this JSON format:
        {{
            "categorizations": [
                {{
                    "product_title": "Product Name",
                    "category": "Category Name",
                    "confidence": 0.95
                }}
            ]
        }}
        """
        return prompt
    
    def _create_summary_prompt(self, brand_data: Dict[str, Any]) -> str:
        """Create a prompt for generating brand summary"""
        prompt = f"""
        You are a brand analyst. Please create a concise, professional summary of the following brand based on the provided information.
        
        Brand data:
        {json.dumps(brand_data, indent=2)}
        
        Please create a 2-3 sentence summary that captures:
        1. What the brand is about
        2. Their key value proposition
        3. Their target audience (if evident)
        
        Keep it professional and concise.
        """
        return prompt
    
    async def _process_with_openai(self, prompt: str) -> Optional[str]:
        """Process prompt with OpenAI API"""
        try:
            if not self.client:
                return None
            
            response = await self.client.chat.completions.create(
                model=self.settings.openai_model,
                messages=[
                    {"role": "system", "content": "You are a helpful data processing assistant. Always respond with valid JSON when requested."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.3
            )
            
            if response.choices and response.choices[0].message.content:
                return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error calling OpenAI API: {str(e)}")
        
        return None
    
    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response into structured data"""
        try:
            # Try to extract JSON from the response
            if '{' in response and '}' in response:
                start = response.find('{')
                end = response.rfind('}') + 1
                json_str = response[start:end]
                
                parsed_data = json.loads(json_str)
                return parsed_data
            else:
                logger.warning("LLM response does not contain valid JSON")
                return {}
                
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing LLM response as JSON: {str(e)}")
            return {}
        except Exception as e:
            logger.error(f"Error parsing LLM response: {str(e)}")
            return {}
    
    def _parse_categorization_response(self, response: str, products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Parse categorization response and apply to products"""
        try:
            parsed_response = self._parse_llm_response(response)
            
            if 'categorizations' in parsed_response:
                categorizations = parsed_response['categorizations']
                
                # Create a mapping of product titles to categories
                category_map = {}
                for cat in categorizations:
                    if 'product_title' in cat and 'category' in cat:
                        category_map[cat['product_title']] = cat['category']
                
                # Apply categories to products
                for product in products:
                    if product.get('title') in category_map:
                        product['category'] = category_map[product['title']]
                
            return products
            
        except Exception as e:
            logger.error(f"Error parsing categorization response: {str(e)}")
            return products
    
    def _extract_summary_from_response(self, response: str) -> Optional[str]:
        """Extract summary text from LLM response"""
        try:
            # Try to extract JSON first
            parsed = self._parse_llm_response(response)
            if 'summary' in parsed:
                return parsed['summary']
            
            # If no JSON, try to extract plain text
            lines = response.strip().split('\n')
            for line in lines:
                line = line.strip()
                if line and not line.startswith('{') and not line.startswith('['):
                    return line
            
            return None
            
        except Exception as e:
            logger.error(f"Error extracting summary from response: {str(e)}")
            return None
    
    async def _enhance_single_product(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """Enhance a single product using LLM"""
        try:
            if not self.client:
                return product
            
            # Create enhancement prompt
            prompt = f"""
            Please enhance the following product description to make it more engaging and informative:
            
            Title: {product.get('title', 'N/A')}
            Current Description: {product.get('description', 'N/A')}
            
            Please:
            1. Make the description more engaging
            2. Add relevant details if missing
            3. Keep it concise but informative
            4. Maintain the original tone and style
            
            Return only the enhanced description, no additional formatting.
            """
            
            response = await self._process_with_openai(prompt)
            
            if response:
                # Clean up the response
                enhanced_description = response.strip()
                if enhanced_description and len(enhanced_description) > 10:
                    product['description'] = enhanced_description
            
            return product
            
        except Exception as e:
            logger.debug(f"Error enhancing single product: {str(e)}")
            return product
