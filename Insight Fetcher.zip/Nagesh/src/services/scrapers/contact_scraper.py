import logging
import re
from typing import Optional
from urllib.parse import urljoin
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import ContactInfo
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class ContactScraper:
    """Service for scraping contact information from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
        
        # Email patterns
        self.email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        
        # Phone patterns
        self.phone_patterns = [
            r'\+?1?[-.\s]?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})',  # US format
            r'\+?[0-9]{1,4}[-.\s]?[0-9]{1,4}[-.\s]?[0-9]{1,4}[-.\s]?[0-9]{1,4}',  # International
            r'\([0-9]{3}\)\s*[0-9]{3}-[0-9]{4}',  # (123) 456-7890
            r'[0-9]{3}-[0-9]{3}-[0-9]{4}',  # 123-456-7890
            r'[0-9]{3}\.[0-9]{3}\.[0-9]{4}',  # 123.456.7890
        ]
    
    async def scrape_contact_info(self, website_url: str, driver: webdriver.Chrome) -> Optional[ContactInfo]:
        """
        Scrape contact information from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            ContactInfo: Contact information found
        """
        try:
            # Try to find contact information using multiple methods
            contact_info = await self._scrape_from_homepage(website_url, driver)
            if not contact_info:
                contact_info = await self._scrape_from_contact_page(website_url, driver)
            if not contact_info:
                contact_info = await self._scrape_from_about_page(website_url, driver)
            if not contact_info:
                contact_info = await self._scrape_from_footer(website_url, driver)
            
            return contact_info
            
        except Exception as e:
            logger.error(f"Error scraping contact info: {str(e)}")
            return None
    
    async def _scrape_from_homepage(self, website_url: str, driver: webdriver.Chrome) -> Optional[ContactInfo]:
        """Scrape contact information from homepage"""
        try:
            if not driver:
                return None
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for contact information
            contact_selectors = [
                '[class*="contact"]',
                '[class*="Contact"]',
                '.contact-info',
                '.contact-details',
                '.contact-section',
                'header',
                'footer'
            ]
            
            for selector in contact_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        contact_info = self._extract_contact_from_element(element)
                        if contact_info and (contact_info.email or contact_info.phone):
                            return contact_info
                except Exception as e:
                    logger.debug(f"Error with contact selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping contact info from homepage: {str(e)}")
        
        return None
    
    async def _scrape_from_contact_page(self, website_url: str, driver: webdriver.Chrome) -> Optional[ContactInfo]:
        """Scrape contact information from contact page"""
        try:
            # Try to find contact page
            contact_patterns = [
                '/contact',
                '/contact-us',
                '/get-in-touch',
                '/reach-us',
                '/pages/contact',
                '/pages/contact-us'
            ]
            
            for pattern in contact_patterns:
                try:
                    contact_url = urljoin(website_url, pattern)
                    if await self._url_exists(contact_url):
                        contact_info = await self._scrape_contact_from_page(contact_url, driver)
                        if contact_info:
                            return contact_info
                except Exception as e:
                    logger.debug(f"Error with contact pattern {pattern}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping contact info from contact page: {str(e)}")
        
        return None
    
    async def _scrape_from_about_page(self, website_url: str, driver: webdriver.Chrome) -> Optional[ContactInfo]:
        """Scrape contact information from about page"""
        try:
            # Try to find about page
            about_patterns = [
                '/about',
                '/about-us',
                '/our-story',
                '/pages/about',
                '/pages/about-us'
            ]
            
            for pattern in about_patterns:
                try:
                    about_url = urljoin(website_url, pattern)
                    if await self._url_exists(about_url):
                        contact_info = await self._scrape_contact_from_page(about_url, driver)
                        if contact_info:
                            return contact_info
                except Exception as e:
                    logger.debug(f"Error with about pattern {pattern}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping contact info from about page: {str(e)}")
        
        return None
    
    async def _scrape_from_footer(self, website_url: str, driver: webdriver.Chrome) -> Optional[ContactInfo]:
        """Scrape contact information from footer"""
        try:
            if not driver:
                return None
            
            # Look for footer
            footer_selectors = [
                'footer',
                '[class*="footer"]',
                '[class*="Footer"]',
                '.site-footer',
                '.main-footer'
            ]
            
            for selector in footer_selectors:
                try:
                    footer = driver.find_element(By.CSS_SELECTOR, selector)
                    contact_info = self._extract_contact_from_element(footer)
                    if contact_info and (contact_info.email or contact_info.phone):
                        return contact_info
                except Exception as e:
                    logger.debug(f"Error with footer selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping contact info from footer: {str(e)}")
        
        return None
    
    async def _scrape_contact_from_page(self, url: str, driver: webdriver.Chrome) -> Optional[ContactInfo]:
        """Scrape contact information from a specific page"""
        try:
            # Try using aiohttp first
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, timeout=self.settings.request_timeout) as response:
                        if response.status == 200:
                            content = await response.text()
                            contact_info = self._extract_contact_from_html(content)
                            if contact_info:
                                return contact_info
            except Exception as e:
                logger.debug(f"aiohttp failed for {url}, trying Selenium: {str(e)}")
            
            # Fallback to Selenium
            if driver:
                driver.get(url)
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                content = driver.page_source
                contact_info = self._extract_contact_from_html(content)
                if contact_info:
                    return contact_info
            
        except Exception as e:
            logger.debug(f"Error scraping contact info from page {url}: {str(e)}")
        
        return None
    
    def _extract_contact_from_element(self, element) -> Optional[ContactInfo]:
        """Extract contact information from a DOM element"""
        try:
            # Get text content
            text = element.text.strip()
            
            # Extract email
            email = self._extract_email(text)
            
            # Extract phone
            phone = self._extract_phone(text)
            
            # Extract address
            address = self._extract_address(text)
            
            # Look for contact form
            contact_form_url = self._extract_contact_form_url(element)
            
            if email or phone or address:
                return ContactInfo(
                    email=email,
                    phone=phone,
                    address=address,
                    contact_form_url=contact_form_url
                )
            
        except Exception as e:
            logger.debug(f"Error extracting contact info from element: {str(e)}")
        
        return None
    
    def _extract_contact_from_html(self, html_content: str) -> Optional[ContactInfo]:
        """Extract contact information from HTML content"""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Get text content
            text = soup.get_text()
            
            # Extract email
            email = self._extract_email(text)
            
            # Extract phone
            phone = self._extract_phone(text)
            
            # Extract address
            address = self._extract_address(text)
            
            # Look for contact form
            contact_form_url = self._extract_contact_form_from_html(soup)
            
            if email or phone or address:
                return ContactInfo(
                    email=email,
                    phone=phone,
                    address=address,
                    contact_form_url=contact_form_url
                )
            
        except Exception as e:
            logger.debug(f"Error extracting contact info from HTML: {str(e)}")
        
        return None
    
    def _extract_email(self, text: str) -> Optional[str]:
        """Extract email address from text"""
        try:
            emails = re.findall(self.email_pattern, text)
            if emails:
                # Return the first valid email
                return emails[0]
        except Exception as e:
            logger.debug(f"Error extracting email: {str(e)}")
        
        return None
    
    def _extract_phone(self, text: str) -> Optional[str]:
        """Extract phone number from text"""
        try:
            for pattern in self.phone_patterns:
                matches = re.findall(pattern, text)
                if matches:
                    # Return the first valid phone number
                    if isinstance(matches[0], tuple):
                        return ''.join(matches[0])
                    else:
                        return matches[0]
        except Exception as e:
            logger.debug(f"Error extracting phone: {str(e)}")
        
        return None
    
    def _extract_address(self, text: str) -> Optional[str]:
        """Extract address from text"""
        try:
            # Look for address patterns
            address_patterns = [
                r'\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Place|Pl|Court|Ct|Way|Terrace|Ter|Circle|Cir|Square|Sq)',
                r'[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Place|Pl|Court|Ct|Way|Terrace|Ter|Circle|Cir|Square|Sq)\s+\d+',
                r'\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Place|Pl|Court|Ct|Way|Terrace|Ter|Circle|Cir|Square|Sq)\s+[A-Za-z\s]+(?:[A-Z]{2}\s+\d{5})?'
            ]
            
            for pattern in address_patterns:
                matches = re.findall(pattern, text)
                if matches:
                    # Return the first valid address
                    address = matches[0].strip()
                    if len(address) > 10 and len(address) < 200:
                        return address
        except Exception as e:
            logger.debug(f"Error extracting address: {str(e)}")
        
        return None
    
    def _extract_contact_form_url(self, element) -> Optional[str]:
        """Extract contact form URL from DOM element"""
        try:
            # Look for contact form links
            form_links = element.find_elements(By.CSS_SELECTOR, "a[href*='contact'], a[href*='form'], a[href*='mailto']")
            
            for link in form_links:
                href = link.get_attribute('href')
                if href and href.startswith('http'):
                    return href
                elif href and href.startswith('mailto:'):
                    return href
            
        except Exception as e:
            logger.debug(f"Error extracting contact form URL: {str(e)}")
        
        return None
    
    def _extract_contact_form_from_html(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract contact form URL from HTML"""
        try:
            # Look for contact form links
            form_links = soup.find_all('a', href=True)
            
            for link in form_links:
                href = link.get('href', '')
                if any(keyword in href.lower() for keyword in ['contact', 'form', 'mailto']):
                    if href.startswith('http'):
                        return href
                    elif href.startswith('mailto:'):
                        return href
            
        except Exception as e:
            logger.debug(f"Error extracting contact form URL from HTML: {str(e)}")
        
        return None
    
    async def _url_exists(self, url: str) -> bool:
        """Check if a URL exists and is accessible"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=self.settings.request_timeout) as response:
                    return response.status == 200
        except Exception:
            return False
