import logging
import re
from typing import Dict, Optional
from urllib.parse import urljoin
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import Policy
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class PolicyScraper:
    """Service for scraping policy information from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
    
    async def scrape_policies(self, website_url: str, driver: webdriver.Chrome) -> Dict[str, Policy]:
        """
        Scrape privacy, return, and refund policies from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            Dict[str, Policy]: Dictionary containing policy types and their content
        """
        policies = {}
        
        try:
            # Try to find policy pages using common patterns
            policy_urls = await self._find_policy_urls(website_url)
            
            # Scrape each policy
            for policy_type, url in policy_urls.items():
                try:
                    policy = await self._scrape_policy_page(url, policy_type, driver)
                    if policy:
                        policies[policy_type] = policy
                except Exception as e:
                    logger.debug(f"Error scraping {policy_type} policy: {str(e)}")
                    continue
            
            # If no policies found via URLs, try to find them in footer/legal sections
            if not policies:
                policies = await self._scrape_policies_from_footer(website_url, driver)
            
            return policies
            
        except Exception as e:
            logger.error(f"Error scraping policies: {str(e)}")
            return {}
    
    async def _find_policy_urls(self, website_url: str) -> Dict[str, str]:
        """Find policy page URLs using common patterns"""
        policy_urls = {}
        
        # Common policy URL patterns
        policy_patterns = {
            'privacy': [
                '/privacy-policy',
                '/privacy',
                '/privacy-policy.html',
                '/legal/privacy-policy',
                '/pages/privacy-policy',
                '/policies/privacy-policy'
            ],
            'return': [
                '/return-policy',
                '/returns',
                '/return-policy.html',
                '/legal/return-policy',
                '/pages/return-policy',
                '/policies/return-policy',
                '/shipping-returns'
            ],
            'refund': [
                '/refund-policy',
                '/refunds',
                '/refund-policy.html',
                '/legal/refund-policy',
                '/pages/refund-policy',
                '/policies/refund-policy'
            ]
        }
        
        # Check each pattern
        for policy_type, patterns in policy_patterns.items():
            for pattern in patterns:
                url = urljoin(website_url, pattern)
                if await self._url_exists(url):
                    policy_urls[policy_type] = url
                    break
        
        return policy_urls
    
    async def _url_exists(self, url: str) -> bool:
        """Check if a URL exists and is accessible"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=self.settings.request_timeout) as response:
                    return response.status == 200
        except Exception:
            return False
    
    async def _scrape_policy_page(self, url: str, policy_type: str, driver: webdriver.Chrome) -> Optional[Policy]:
        """Scrape a single policy page"""
        try:
            # Try using aiohttp first (faster)
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, timeout=self.settings.request_timeout) as response:
                        if response.status == 200:
                            content = await response.text()
                            return self._parse_policy_content(content, policy_type, url)
            except Exception as e:
                logger.debug(f"aiohttp failed for {url}, trying Selenium: {str(e)}")
            
            # Fallback to Selenium for JavaScript-heavy pages
            if driver:
                driver.get(url)
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                content = driver.page_source
                return self._parse_policy_content(content, policy_type, url)
            
        except Exception as e:
            logger.debug(f"Error scraping policy page {url}: {str(e)}")
        
        return None
    
    def _parse_policy_content(self, html_content: str, policy_type: str, url: str) -> Optional[Policy]:
        """Parse policy content from HTML"""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Try to find the main content area
            content_selectors = [
                'main',
                'article',
                '.content',
                '.main-content',
                '.policy-content',
                '.legal-content',
                '[class*="policy"]',
                '[class*="legal"]'
            ]
            
            content_element = None
            for selector in content_selectors:
                content_element = soup.select_one(selector)
                if content_element:
                    break
            
            if not content_element:
                # Fallback to body content
                content_element = soup.find('body')
            
            if content_element:
                # Extract title
                title = self._extract_policy_title(soup, policy_type)
                
                # Extract content
                content = content_element.get_text(separator='\n', strip=True)
                
                # Clean up content
                content = self._clean_policy_content(content)
                
                if content and len(content) > 50:  # Ensure we have meaningful content
                    return Policy(
                        title=title,
                        content=content,
                        url=url
                    )
            
        except Exception as e:
            logger.debug(f"Error parsing policy content: {str(e)}")
        
        return None
    
    def _extract_policy_title(self, soup: BeautifulSoup, policy_type: str) -> str:
        """Extract policy title from the page"""
        # Try to find the main heading
        title_selectors = [
            'h1',
            'h1[class*="title"]',
            'h1[class*="policy"]',
            '.page-title',
            '.policy-title'
        ]
        
        for selector in title_selectors:
            element = soup.select_one(selector)
            if element:
                title = element.get_text().strip()
                if title:
                    return title
        
        # Fallback to default titles
        default_titles = {
            'privacy': 'Privacy Policy',
            'return': 'Return Policy',
            'refund': 'Refund Policy'
        }
        
        return default_titles.get(policy_type, f"{policy_type.title()} Policy")
    
    def _clean_policy_content(self, content: str) -> str:
        """Clean and format policy content"""
        if not content:
            return ""
        
        # Remove excessive whitespace
        content = re.sub(r'\n\s*\n', '\n\n', content)
        content = re.sub(r' +', ' ', content)
        
        # Remove common boilerplate text
        boilerplate_patterns = [
            r'Last updated.*?\n',
            r'Effective date.*?\n',
            r'©.*?\n',
            r'All rights reserved.*?\n'
        ]
        
        for pattern in boilerplate_patterns:
            content = re.sub(pattern, '', content, flags=re.IGNORECASE)
        
        # Clean up and return
        content = content.strip()
        
        # Limit content length to reasonable size
        if len(content) > 10000:
            content = content[:10000] + "... [Content truncated for length]"
        
        return content
    
    async def _scrape_policies_from_footer(self, website_url: str, driver: webdriver.Chrome) -> Dict[str, Policy]:
        """Scrape policies from footer/legal sections when dedicated pages aren't found"""
        policies = {}
        
        try:
            if not driver:
                return policies
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for footer links
            footer_selectors = [
                'footer',
                '[class*="footer"]',
                '[class*="Footer"]',
                '.site-footer',
                '.main-footer'
            ]
            
            for selector in footer_selectors:
                try:
                    footer = driver.find_element(By.CSS_SELECTOR, selector)
                    policies.update(self._extract_policies_from_footer(footer, website_url))
                except Exception as e:
                    logger.debug(f"Error with footer selector {selector}: {str(e)}")
                    continue
            
            # Also check for legal links in navigation
            nav_selectors = [
                'nav',
                '[class*="nav"]',
                '[class*="menu"]',
                '.main-nav',
                '.site-nav'
            ]
            
            for selector in nav_selectors:
                try:
                    nav = driver.find_element(By.CSS_SELECTOR, selector)
                    policies.update(self._extract_policies_from_nav(nav, website_url))
                except Exception as e:
                    logger.debug(f"Error with nav selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.error(f"Error scraping policies from footer: {str(e)}")
        
        return policies
    
    def _extract_policies_from_footer(self, footer_element, website_url: str) -> Dict[str, Policy]:
        """Extract policy information from footer element"""
        policies = {}
        
        try:
            # Look for policy links
            policy_links = footer_element.find_elements(By.CSS_SELECTOR, "a[href*='policy'], a[href*='legal'], a[href*='terms']")
            
            for link in policy_links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip().lower()
                    
                    if not href or not text:
                        continue
                    
                    # Determine policy type
                    policy_type = self._determine_policy_type(text, href)
                    if policy_type:
                        # Extract content from the link text and nearby elements
                        content = self._extract_policy_content_from_element(link)
                        if content:
                            policies[policy_type] = Policy(
                                title=f"{policy_type.title()} Policy",
                                content=content,
                                url=href
                            )
                
                except Exception as e:
                    logger.debug(f"Error extracting policy from footer link: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error extracting policies from footer: {str(e)}")
        
        return policies
    
    def _extract_policies_from_nav(self, nav_element, website_url: str) -> Dict[str, Policy]:
        """Extract policy information from navigation element"""
        policies = {}
        
        try:
            # Look for legal/policy links in navigation
            legal_links = nav_element.find_elements(By.CSS_SELECTOR, "a[href*='legal'], a[href*='policy'], a[href*='terms']")
            
            for link in legal_links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip().lower()
                    
                    if not href or not text:
                        continue
                    
                    # Determine policy type
                    policy_type = self._determine_policy_type(text, href)
                    if policy_type:
                        # Extract content from the link text and nearby elements
                        content = self._extract_policy_content_from_element(link)
                        if content:
                            policies[policy_type] = Policy(
                                title=f"{policy_type.title()} Policy",
                                content=content,
                                url=href
                            )
                
                except Exception as e:
                    logger.debug(f"Error extracting policy from nav link: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error extracting policies from nav: {str(e)}")
        
        return policies
    
    def _determine_policy_type(self, text: str, href: str) -> Optional[str]:
        """Determine the type of policy based on text and URL"""
        text_lower = text.lower()
        href_lower = href.lower()
        
        if any(word in text_lower for word in ['privacy', 'privacy-policy']):
            return 'privacy'
        elif any(word in text_lower for word in ['return', 'returns', 'return-policy']):
            return 'return'
        elif any(word in text_lower for word in ['refund', 'refunds', 'refund-policy']):
            return 'refund'
        elif any(word in text_lower for word in ['legal', 'terms', 'policy']):
            # Check URL for more specific information
            if 'privacy' in href_lower:
                return 'privacy'
            elif 'return' in href_lower:
                return 'return'
            elif 'refund' in href_lower:
                return 'refund'
        
        return None
    
    def _extract_policy_content_from_element(self, element) -> Optional[str]:
        """Extract policy content from a DOM element"""
        try:
            # Get text from the element and its children
            content = element.text.strip()
            
            # Also try to get content from nearby elements
            try:
                parent = element.find_element(By.XPATH, "..")
                parent_text = parent.text.strip()
                if len(parent_text) > len(content):
                    content = parent_text
            except Exception:
                pass
            
            # Clean up content
            if content:
                content = re.sub(r'\n\s*\n', '\n\n', content)
                content = re.sub(r' +', ' ', content)
                content = content.strip()
                
                # Only return if we have meaningful content
                if len(content) > 20:
                    return content
            
        except Exception as e:
            logger.debug(f"Error extracting policy content from element: {str(e)}")
        
        return None
