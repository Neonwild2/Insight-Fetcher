import logging
from typing import List, Optional
from urllib.parse import urljoin
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import ImportantLink
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class LinkScraper:
    """Service for scraping important links from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
        
        # Important link patterns and keywords
        self.important_link_patterns = {
            'order_tracking': [
                'track', 'tracking', 'order-status', 'order-status',
                'my-orders', 'orders', 'order-history'
            ],
            'contact': [
                'contact', 'contact-us', 'get-in-touch', 'reach-us',
                'support', 'help', 'customer-service'
            ],
            'blog': [
                'blog', 'news', 'articles', 'stories', 'journal',
                'magazine', 'updates'
            ],
            'about': [
                'about', 'about-us', 'our-story', 'who-we-are',
                'company', 'team'
            ],
            'shipping': [
                'shipping', 'delivery', 'shipping-info', 'shipping-policy',
                'delivery-info', 'shipping-returns'
            ],
            'returns': [
                'returns', 'refunds', 'return-policy', 'refund-policy',
                'shipping-returns', 'exchanges'
            ],
            'faq': [
                'faq', 'faqs', 'frequently-asked-questions', 'help',
                'support', 'questions'
            ],
            'size_guide': [
                'size-guide', 'sizing', 'size-chart', 'measurements',
                'fit-guide', 'size-help'
            ],
            'privacy': [
                'privacy', 'privacy-policy', 'privacy-statement',
                'data-protection'
            ],
            'terms': [
                'terms', 'terms-of-service', 'terms-and-conditions',
                'legal', 'terms-of-use'
            ]
        }
    
    async def scrape_important_links(self, website_url: str, driver: webdriver.Chrome) -> List[ImportantLink]:
        """
        Scrape important links from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            List[ImportantLink]: List of important links found
        """
        important_links = []
        
        try:
            # Try to find important links using multiple methods
            important_links.extend(await self._scrape_from_navigation(website_url, driver))
            important_links.extend(await self._scrape_from_footer(website_url, driver))
            important_links.extend(await self._scrape_from_homepage(website_url, driver))
            
            # Remove duplicates and clean up
            important_links = self._deduplicate_links(important_links)
            
            return important_links
            
        except Exception as e:
            logger.error(f"Error scraping important links: {str(e)}")
            return []
    
    async def _scrape_from_navigation(self, website_url: str, driver: webdriver.Chrome) -> List[ImportantLink]:
        """Scrape important links from navigation menu"""
        important_links = []
        
        try:
            if not driver:
                return important_links
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for navigation menus
            nav_selectors = [
                'nav',
                '[class*="nav"]',
                '[class*="menu"]',
                '.main-nav',
                '.site-nav',
                '.primary-nav',
                'header'
            ]
            
            for selector in nav_selectors:
                try:
                    nav_elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for nav in nav_elements:
                        nav_links = self._extract_important_links_from_element(nav, website_url)
                        important_links.extend(nav_links)
                except Exception as e:
                    logger.debug(f"Error with nav selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping important links from navigation: {str(e)}")
        
        return important_links
    
    async def _scrape_from_footer(self, website_url: str, driver: webdriver.Chrome) -> List[ImportantLink]:
        """Scrape important links from footer"""
        important_links = []
        
        try:
            if not driver:
                return important_links
            
            # Look for footer
            footer_selectors = [
                'footer',
                '[class*="footer"]',
                '[class*="Footer"]',
                '.site-footer',
                '.main-footer'
            ]
            
            for selector in footer_selectors:
                try:
                    footer = driver.find_element(By.CSS_SELECTOR, selector)
                    footer_links = self._extract_important_links_from_element(footer, website_url)
                    important_links.extend(footer_links)
                except Exception as e:
                    logger.debug(f"Error with footer selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping important links from footer: {str(e)}")
        
        return important_links
    
    async def _scrape_from_homepage(self, website_url: str, driver: webdriver.Chrome) -> List[ImportantLink]:
        """Scrape important links from homepage"""
        important_links = []
        
        try:
            if not driver:
                return important_links
            
            # Look for additional links on homepage
            link_selectors = [
                '[class*="quick-links"]',
                '[class*="useful-links"]',
                '[class*="helpful-links"]',
                '.quick-links',
                '.useful-links',
                '.helpful-links'
            ]
            
            for selector in link_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        element_links = self._extract_important_links_from_element(element, website_url)
                        important_links.extend(element_links)
                except Exception as e:
                    logger.debug(f"Error with link selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping important links from homepage: {str(e)}")
        
        return important_links
    
    def _extract_important_links_from_element(self, element, website_url: str) -> List[ImportantLink]:
        """Extract important links from a DOM element"""
        important_links = []
        
        try:
            # Get all links in the element
            links = element.find_elements(By.CSS_SELECTOR, "a[href]")
            
            for link in links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip()
                    
                    if not href or not text:
                        continue
                    
                    # Check if this is an important link
                    link_type = self._determine_link_type(href, text)
                    if link_type:
                        # Create full URL if relative
                        if not href.startswith('http'):
                            href = urljoin(website_url, href)
                        
                        important_links.append(ImportantLink(
                            title=text,
                            url=href,
                            description=self._generate_link_description(link_type, text)
                        ))
                
                except Exception as e:
                    logger.debug(f"Error extracting link: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error extracting important links from element: {str(e)}")
        
        return important_links
    
    def _determine_link_type(self, href: str, text: str) -> Optional[str]:
        """Determine the type of important link"""
        href_lower = href.lower()
        text_lower = text.lower()
        
        # Check each link type pattern
        for link_type, patterns in self.important_link_patterns.items():
            for pattern in patterns:
                if pattern in href_lower or pattern in text_lower:
                    return link_type
        
        return None
    
    def _generate_link_description(self, link_type: str, text: str) -> str:
        """Generate a description for the link based on its type"""
        descriptions = {
            'order_tracking': 'Track your order status and delivery information',
            'contact': 'Get in touch with customer support and sales team',
            'blog': 'Read latest news, articles, and brand updates',
            'about': 'Learn more about the company and brand story',
            'shipping': 'Information about shipping methods and delivery',
            'returns': 'Return and refund policy information',
            'faq': 'Frequently asked questions and answers',
            'size_guide': 'Size charts and fitting information',
            'privacy': 'Privacy policy and data protection information',
            'terms': 'Terms of service and legal information'
        }
        
        return descriptions.get(link_type, f'Important {text} page')
    
    def _deduplicate_links(self, links: List[ImportantLink]) -> List[ImportantLink]:
        """Remove duplicate links based on URL and title"""
        if not links:
            return []
        
        # Remove duplicates based on URL
        unique_links = []
        seen_urls = set()
        
        for link in links:
            if link.url not in seen_urls:
                seen_urls.add(link.url)
                unique_links.append(link)
        
        return unique_links
