import logging
import re
from typing import List, Optional
from urllib.parse import urljoin
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import SocialHandle
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class SocialScraper:
    """Service for scraping social media handles from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
        
        # Common social media platforms and their patterns
        self.social_patterns = {
            'instagram': {
                'url_patterns': [
                    r'instagram\.com/([^/\s]+)',
                    r'instagram\.com/([^/\s]+)/?$'
                ],
                'text_patterns': [
                    r'@([a-zA-Z0-9._]+)',
                    r'instagram\.com/([^/\s]+)'
                ]
            },
            'facebook': {
                'url_patterns': [
                    r'facebook\.com/([^/\s]+)',
                    r'fb\.com/([^/\s]+)'
                ],
                'text_patterns': [
                    r'facebook\.com/([^/\s]+)',
                    r'fb\.com/([^/\s]+)'
                ]
            },
            'twitter': {
                'url_patterns': [
                    r'twitter\.com/([^/\s]+)',
                    r'x\.com/([^/\s]+)'
                ],
                'text_patterns': [
                    r'@([a-zA-Z0-9._]+)',
                    r'twitter\.com/([^/\s]+)',
                    r'x\.com/([^/\s]+)'
                ]
            },
            'tiktok': {
                'url_patterns': [
                    r'tiktok\.com/@([^/\s]+)',
                    r'tiktok\.com/([^/\s]+)'
                ],
                'text_patterns': [
                    r'@([a-zA-Z0-9._]+)',
                    r'tiktok\.com/@([^/\s]+)'
                ]
            },
            'youtube': {
                'url_patterns': [
                    r'youtube\.com/([^/\s]+)',
                    r'youtube\.com/channel/([^/\s]+)',
                    r'youtube\.com/c/([^/\s]+)'
                ],
                'text_patterns': [
                    r'youtube\.com/([^/\s]+)',
                    r'youtube\.com/channel/([^/\s]+)'
                ]
            },
            'linkedin': {
                'url_patterns': [
                    r'linkedin\.com/company/([^/\s]+)',
                    r'linkedin\.com/in/([^/\s]+)'
                ],
                'text_patterns': [
                    r'linkedin\.com/company/([^/\s]+)',
                    r'linkedin\.com/in/([^/\s]+)'
                ]
            },
            'pinterest': {
                'url_patterns': [
                    r'pinterest\.com/([^/\s]+)',
                    r'pinterest\.([a-z]{2})/([^/\s]+)'
                ],
                'text_patterns': [
                    r'pinterest\.com/([^/\s]+)'
                ]
            }
        }
    
    async def scrape_social_handles(self, website_url: str, driver: webdriver.Chrome) -> List[SocialHandle]:
        """
        Scrape social media handles from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            List[SocialHandle]: List of social media handles found
        """
        social_handles = []
        
        try:
            # Try to find social handles using multiple methods
            social_handles.extend(await self._scrape_from_homepage(website_url, driver))
            social_handles.extend(await self._scrape_from_footer(website_url, driver))
            social_handles.extend(await self._scrape_from_contact_page(website_url, driver))
            
            # Remove duplicates and clean up
            social_handles = self._deduplicate_social_handles(social_handles)
            
            return social_handles
            
        except Exception as e:
            logger.error(f"Error scraping social handles: {str(e)}")
            return []
    
    async def _scrape_from_homepage(self, website_url: str, driver: webdriver.Chrome) -> List[SocialHandle]:
        """Scrape social handles from homepage"""
        social_handles = []
        
        try:
            if not driver:
                return social_handles
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for social media links
            social_selectors = [
                '[class*="social"]',
                '[class*="Social"]',
                '.social-links',
                '.social-media',
                '.social-icons',
                'footer a[href*="facebook"], footer a[href*="instagram"], footer a[href*="twitter"]',
                'header a[href*="facebook"], header a[href*="instagram"], header a[href*="twitter"]'
            ]
            
            for selector in social_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        element_handles = self._extract_social_handles_from_element(element)
                        social_handles.extend(element_handles)
                except Exception as e:
                    logger.debug(f"Error with social selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping social handles from homepage: {str(e)}")
        
        return social_handles
    
    async def _scrape_from_footer(self, website_url: str, driver: webdriver.Chrome) -> List[SocialHandle]:
        """Scrape social handles from footer"""
        social_handles = []
        
        try:
            if not driver:
                return social_handles
            
            # Look for footer
            footer_selectors = [
                'footer',
                '[class*="footer"]',
                '[class*="Footer"]',
                '.site-footer',
                '.main-footer'
            ]
            
            for selector in footer_selectors:
                try:
                    footer = driver.find_element(By.CSS_SELECTOR, selector)
                    footer_handles = self._extract_social_handles_from_element(footer)
                    social_handles.extend(footer_handles)
                except Exception as e:
                    logger.debug(f"Error with footer selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping social handles from footer: {str(e)}")
        
        return social_handles
    
    async def _scrape_from_contact_page(self, website_url: str, driver: webdriver.Chrome) -> List[SocialHandle]:
        """Scrape social handles from contact page"""
        social_handles = []
        
        try:
            # Try to find contact page
            contact_patterns = [
                '/contact',
                '/contact-us',
                '/about',
                '/about-us',
                '/pages/contact',
                '/pages/about'
            ]
            
            for pattern in contact_patterns:
                try:
                    contact_url = urljoin(website_url, pattern)
                    if await self._url_exists(contact_url):
                        page_handles = await self._scrape_social_from_page(contact_url, driver)
                        social_handles.extend(page_handles)
                        break
                except Exception as e:
                    logger.debug(f"Error with contact pattern {pattern}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping social handles from contact page: {str(e)}")
        
        return social_handles
    
    async def _scrape_social_from_page(self, url: str, driver: webdriver.Chrome) -> List[SocialHandle]:
        """Scrape social handles from a specific page"""
        social_handles = []
        
        try:
            # Try using aiohttp first
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, timeout=self.settings.request_timeout) as response:
                        if response.status == 200:
                            content = await response.text()
                            social_handles = self._extract_social_handles_from_html(content)
            except Exception as e:
                logger.debug(f"aiohttp failed for {url}, trying Selenium: {str(e)}")
            
            # Fallback to Selenium
            if not social_handles and driver:
                driver.get(url)
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                content = driver.page_source
                social_handles = self._extract_social_handles_from_html(content)
            
        except Exception as e:
            logger.debug(f"Error scraping social handles from page {url}: {str(e)}")
        
        return social_handles
    
    def _extract_social_handles_from_element(self, element) -> List[SocialHandle]:
        """Extract social handles from a DOM element"""
        social_handles = []
        
        try:
            # Look for social media links
            social_links = element.find_elements(By.CSS_SELECTOR, "a[href*='facebook'], a[href*='instagram'], a[href*='twitter'], a[href*='tiktok'], a[href*='youtube'], a[href*='linkedin'], a[href*='pinterest']")
            
            for link in social_links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip()
                    
                    if not href:
                        continue
                    
                    # Extract social handle from URL
                    social_handle = self._extract_social_handle_from_url(href, text)
                    if social_handle:
                        social_handles.append(social_handle)
                
                except Exception as e:
                    logger.debug(f"Error extracting social handle from link: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error extracting social handles from element: {str(e)}")
        
        return social_handles
    
    def _extract_social_handles_from_html(self, html_content: str) -> List[SocialHandle]:
        """Extract social handles from HTML content"""
        social_handles = []
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Look for social media links
            social_links = soup.find_all('a', href=True)
            
            for link in social_links:
                href = link.get('href', '')
                text = link.get_text().strip()
                
                if not href:
                    continue
                
                # Extract social handle from URL
                social_handle = self._extract_social_handle_from_url(href, text)
                if social_handle:
                    social_handles.append(social_handle)
            
        except Exception as e:
            logger.debug(f"Error extracting social handles from HTML: {str(e)}")
        
        return social_handles
    
    def _extract_social_handle_from_url(self, url: str, text: str) -> Optional[SocialHandle]:
        """Extract social handle information from a URL"""
        try:
            url_lower = url.lower()
            
            # Check each social platform
            for platform, patterns in self.social_patterns.items():
                # Check URL patterns
                for url_pattern in patterns['url_patterns']:
                    match = re.search(url_pattern, url_lower)
                    if match:
                        handle = match.group(1)
                        if handle:
                            return SocialHandle(
                                platform=platform,
                                handle=handle,
                                url=url
                            )
                
                # Check text patterns
                for text_pattern in patterns['text_patterns']:
                    match = re.search(text_pattern, text.lower())
                    if match:
                        handle = match.group(1)
                        if handle:
                            return SocialHandle(
                                platform=platform,
                                handle=handle,
                                url=url
                            )
            
        except Exception as e:
            logger.debug(f"Error extracting social handle from URL {url}: {str(e)}")
        
        return None
    
    async def _url_exists(self, url: str) -> bool:
        """Check if a URL exists and is accessible"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=self.settings.request_timeout) as response:
                    return response.status == 200
        except Exception:
            return False
    
    def _deduplicate_social_handles(self, social_handles: List[SocialHandle]) -> List[SocialHandle]:
        """Remove duplicate social handles"""
        if not social_handles:
            return []
        
        # Remove duplicates based on platform and handle
        unique_handles = []
        seen = set()
        
        for handle in social_handles:
            key = (handle.platform.lower(), handle.handle.lower())
            if key not in seen:
                seen.add(key)
                unique_handles.append(handle)
        
        return unique_handles
