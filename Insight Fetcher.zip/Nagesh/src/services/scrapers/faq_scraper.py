import logging
import re
from typing import List, Optional
from urllib.parse import urljoin
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import FAQ
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class FAQScraper:
    """Service for scraping FAQ information from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
    
    async def scrape_faqs(self, website_url: str, driver: webdriver.Chrome) -> List[FAQ]:
        """
        Scrape frequently asked questions from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            List[FAQ]: List of FAQ items found
        """
        faqs = []
        
        try:
            # Try to find FAQ pages using common patterns
            faq_urls = await self._find_faq_urls(website_url)
            
            # Scrape each FAQ page
            for url in faq_urls:
                try:
                    page_faqs = await self._scrape_faq_page(url, driver)
                    faqs.extend(page_faqs)
                except Exception as e:
                    logger.debug(f"Error scraping FAQ page {url}: {str(e)}")
                    continue
            
            # If no FAQs found via URLs, try to find them in homepage or other sections
            if not faqs:
                faqs = await self._scrape_faqs_from_homepage(website_url, driver)
            
            # Clean and deduplicate FAQs
            faqs = self._clean_and_deduplicate_faqs(faqs)
            
            return faqs
            
        except Exception as e:
            logger.error(f"Error scraping FAQs: {str(e)}")
            return []
    
    async def _find_faq_urls(self, website_url: str) -> List[str]:
        """Find FAQ page URLs using common patterns"""
        faq_urls = []
        
        # Common FAQ URL patterns
        faq_patterns = [
            '/faq',
            '/faqs',
            '/frequently-asked-questions',
            '/help',
            '/support',
            '/customer-service',
            '/faq.html',
            '/faqs.html',
            '/pages/faq',
            '/pages/faqs',
            '/pages/frequently-asked-questions',
            '/pages/help',
            '/pages/support'
        ]
        
        # Check each pattern
        for pattern in faq_patterns:
            url = urljoin(website_url, pattern)
            if await self._url_exists(url):
                faq_urls.append(url)
        
        return faq_urls
    
    async def _url_exists(self, url: str) -> bool:
        """Check if a URL exists and is accessible"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=self.settings.request_timeout) as response:
                    return response.status == 200
        except Exception:
            return False
    
    async def _scrape_faq_page(self, url: str, driver: webdriver.Chrome) -> List[FAQ]:
        """Scrape FAQs from a single FAQ page"""
        faqs = []
        
        try:
            # Try using aiohttp first (faster)
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, timeout=self.settings.request_timeout) as response:
                        if response.status == 200:
                            content = await response.text()
                            faqs = self._parse_faq_content(content, url)
            except Exception as e:
                logger.debug(f"aiohttp failed for {url}, trying Selenium: {str(e)}")
            
            # Fallback to Selenium for JavaScript-heavy pages
            if not faqs and driver:
                driver.get(url)
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                content = driver.page_source
                faqs = self._parse_faq_content(content, url)
            
        except Exception as e:
            logger.debug(f"Error scraping FAQ page {url}: {str(e)}")
        
        return faqs
    
    def _parse_faq_content(self, html_content: str, url: str) -> List[FAQ]:
        """Parse FAQ content from HTML"""
        faqs = []
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Try multiple FAQ parsing strategies
            faqs.extend(self._parse_faq_accordion(soup, url))
            faqs.extend(self._parse_faq_list(soup, url))
            faqs.extend(self._parse_faq_definition_list(soup, url))
            faqs.extend(self._parse_faq_sections(soup, url))
            
        except Exception as e:
            logger.debug(f"Error parsing FAQ content: {str(e)}")
        
        return faqs
    
    def _parse_faq_accordion(self, soup: BeautifulSoup, url: str) -> List[FAQ]:
        """Parse FAQ content from accordion-style layouts"""
        faqs = []
        
        # Common accordion selectors
        accordion_selectors = [
            '[class*="accordion"]',
            '[class*="faq"]',
            '[class*="collapse"]',
            '[class*="expand"]',
            '.faq-item',
            '.faq-accordion',
            '.accordion-item'
        ]
        
        for selector in accordion_selectors:
            try:
                items = soup.select(selector)
                for item in items:
                    faq = self._extract_faq_from_accordion_item(item)
                    if faq:
                        faqs.append(faq)
            except Exception as e:
                logger.debug(f"Error with accordion selector {selector}: {str(e)}")
                continue
        
        return faqs
    
    def _parse_faq_list(self, soup: BeautifulSoup, url: str) -> List[FAQ]:
        """Parse FAQ content from list-style layouts"""
        faqs = []
        
        # Look for FAQ lists
        list_selectors = [
            'ul[class*="faq"]',
            'ol[class*="faq"]',
            '.faq-list ul',
            '.faq-list ol',
            '.faqs ul',
            '.faqs ol'
        ]
        
        for selector in list_selectors:
            try:
                lists = soup.select(selector)
                for list_elem in lists:
                    list_items = list_elem.find_all('li')
                    for i in range(0, len(list_items) - 1, 2):
                        if i + 1 < len(list_items):
                            question = list_items[i].get_text().strip()
                            answer = list_items[i + 1].get_text().strip()
                            
                            if question and answer and len(question) < 200 and len(answer) < 1000:
                                faqs.append(FAQ(
                                    question=question,
                                    answer=answer
                                ))
            except Exception as e:
                logger.debug(f"Error with list selector {selector}: {str(e)}")
                continue
        
        return faqs
    
    def _parse_faq_definition_list(self, soup: BeautifulSoup, url: str) -> List[FAQ]:
        """Parse FAQ content from definition list layouts"""
        faqs = []
        
        # Look for definition lists
        dl_selectors = [
            'dl[class*="faq"]',
            '.faq-list dl',
            '.faqs dl'
        ]
        
        for selector in dl_selectors:
            try:
                dl_elements = soup.select(selector)
                for dl in dl_elements:
                    dts = dl.find_all('dt')
                    dds = dl.find_all('dd')
                    
                    for i, dt in enumerate(dts):
                        if i < len(dds):
                            question = dt.get_text().strip()
                            answer = dds[i].get_text().strip()
                            
                            if question and answer and len(question) < 200 and len(answer) < 1000:
                                faqs.append(FAQ(
                                    question=question,
                                    answer=answer
                                ))
            except Exception as e:
                logger.debug(f"Error with definition list selector {selector}: {str(e)}")
                continue
        
        return faqs
    
    def _parse_faq_sections(self, soup: BeautifulSoup, url: str) -> List[FAQ]:
        """Parse FAQ content from section-based layouts"""
        faqs = []
        
        # Look for FAQ sections
        section_selectors = [
            'section[class*="faq"]',
            'div[class*="faq"]',
            '.faq-section',
            '.faqs-section'
        ]
        
        for selector in section_selectors:
            try:
                sections = soup.select(selector)
                for section in sections:
                    # Look for question-answer pairs within sections
                    questions = section.find_all(['h3', 'h4', 'h5', 'strong', 'b'])
                    
                    for question_elem in questions:
                        question = question_elem.get_text().strip()
                        if not question or len(question) > 200:
                            continue
                        
                        # Look for answer in next sibling or parent
                        answer = self._find_answer_for_question(question_elem)
                        if answer and len(answer) < 1000:
                            faqs.append(FAQ(
                                question=question,
                                answer=answer
                            ))
            except Exception as e:
                logger.debug(f"Error with section selector {selector}: {str(e)}")
                continue
        
        return faqs
    
    def _extract_faq_from_accordion_item(self, item) -> Optional[FAQ]:
        """Extract FAQ from an accordion item"""
        try:
            # Look for question and answer elements
            question_selectors = [
                '[class*="question"]',
                '[class*="title"]',
                'h3', 'h4', 'h5',
                'button',
                'summary'
            ]
            
            answer_selectors = [
                '[class*="answer"]',
                '[class*="content"]',
                '[class*="body"]',
                '[class*="panel"]'
            ]
            
            question = None
            answer = None
            
            # Extract question
            for selector in question_selectors:
                question_elem = item.select_one(selector)
                if question_elem:
                    question = question_elem.get_text().strip()
                    if question:
                        break
            
            # Extract answer
            for selector in answer_selectors:
                answer_elem = item.select_one(selector)
                if answer_elem:
                    answer = answer_elem.get_text().strip()
                    if answer:
                        break
            
            # If we have both question and answer, create FAQ
            if question and answer and len(question) < 200 and len(answer) < 1000:
                return FAQ(
                    question=question,
                    answer=answer
                )
            
        except Exception as e:
            logger.debug(f"Error extracting FAQ from accordion item: {str(e)}")
        
        return None
    
    def _find_answer_for_question(self, question_elem) -> Optional[str]:
        """Find the answer text for a given question element"""
        try:
            # Try to find answer in next sibling
            next_sibling = question_elem.find_next_sibling()
            if next_sibling:
                answer = next_sibling.get_text().strip()
                if answer and len(answer) < 1000:
                    return answer
            
            # Try to find answer in parent's next sibling
            parent = question_elem.parent
            if parent:
                next_sibling = parent.find_next_sibling()
                if next_sibling:
                    answer = next_sibling.get_text().strip()
                    if answer and len(answer) < 1000:
                        return answer
            
            # Try to find answer in the same container
            container = question_elem.parent
            if container:
                # Look for text after the question
                text_parts = container.get_text().split(question)
                if len(text_parts) > 1:
                    answer = text_parts[1].strip()
                    if answer and len(answer) < 1000:
                        return answer
            
        except Exception as e:
            logger.debug(f"Error finding answer for question: {str(e)}")
        
        return None
    
    async def _scrape_faqs_from_homepage(self, website_url: str, driver: webdriver.Chrome) -> List[FAQ]:
        """Scrape FAQs from homepage when dedicated FAQ pages aren't found"""
        faqs = []
        
        try:
            if not driver:
                return faqs
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for FAQ sections on homepage
            faq_selectors = [
                '[class*="faq"]',
                '[class*="FAQ"]',
                '.faq-section',
                '.faqs-section',
                'section[class*="faq"]',
                'div[class*="faq"]'
            ]
            
            for selector in faq_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        element_faqs = self._extract_faqs_from_element(element)
                        faqs.extend(element_faqs)
                except Exception as e:
                    logger.debug(f"Error with FAQ selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.error(f"Error scraping FAQs from homepage: {str(e)}")
        
        return faqs
    
    def _extract_faqs_from_element(self, element) -> List[FAQ]:
        """Extract FAQs from a DOM element"""
        faqs = []
        
        try:
            # Look for question-answer patterns
            questions = element.find_elements(By.CSS_SELECTOR, "h3, h4, h5, strong, b, [class*='question']")
            
            for question_elem in questions:
                try:
                    question = question_elem.text.strip()
                    if not question or len(question) > 200:
                        continue
                    
                    # Look for answer
                    answer = self._find_answer_in_element(question_elem, element)
                    if answer and len(answer) < 1000:
                        faqs.append(FAQ(
                            question=question,
                            answer=answer
                        ))
                
                except Exception as e:
                    logger.debug(f"Error extracting FAQ from element: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error extracting FAQs from element: {str(e)}")
        
        return faqs
    
    def _find_answer_in_element(self, question_elem, container_element) -> Optional[str]:
        """Find answer text within a container element"""
        try:
            # Try to find answer in next sibling
            try:
                next_sibling = question_elem.find_element(By.XPATH, "following-sibling::*[1]")
                answer = next_sibling.text.strip()
                if answer and len(answer) < 1000:
                    return answer
            except Exception:
                pass
            
            # Try to find answer in the same container
            container_text = container_element.text
            question_text = question_elem.text.strip()
            
            if question_text in container_text:
                parts = container_text.split(question_text)
                if len(parts) > 1:
                    answer = parts[1].strip()
                    if answer and len(answer) < 1000:
                        return answer
            
        except Exception as e:
            logger.debug(f"Error finding answer in element: {str(e)}")
        
        return None
    
    def _clean_and_deduplicate_faqs(self, faqs: List[FAQ]) -> List[FAQ]:
        """Clean and remove duplicate FAQs"""
        if not faqs:
            return []
        
        # Clean FAQ content
        cleaned_faqs = []
        for faq in faqs:
            # Clean question
            question = self._clean_text(faq.question)
            # Clean answer
            answer = self._clean_text(faq.answer)
            
            if question and answer and len(question) > 5 and len(answer) > 10:
                cleaned_faqs.append(FAQ(
                    question=question,
                    answer=answer,
                    category=faq.category
                ))
        
        # Remove duplicates based on question similarity
        unique_faqs = []
        seen_questions = set()
        
        for faq in cleaned_faqs:
            # Create a normalized version of the question for comparison
            normalized_question = self._normalize_question(faq.question)
            
            if normalized_question not in seen_questions:
                seen_questions.add(normalized_question)
                unique_faqs.append(faq)
        
        return unique_faqs
    
    def _clean_text(self, text: str) -> str:
        """Clean and format text"""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\n\s*\n', '\n\n', text)
        text = re.sub(r' +', ' ', text)
        
        # Remove common unwanted characters
        text = re.sub(r'[^\w\s\.,!?;:()\-]', '', text)
        
        return text.strip()
    
    def _normalize_question(self, question: str) -> str:
        """Normalize question for deduplication"""
        if not question:
            return ""
        
        # Convert to lowercase
        normalized = question.lower()
        
        # Remove common punctuation
        normalized = re.sub(r'[^\w\s]', '', normalized)
        
        # Remove extra whitespace
        normalized = re.sub(r'\s+', ' ', normalized)
        
        return normalized.strip()
