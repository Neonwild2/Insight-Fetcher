import json
import logging
import re
from typing import List, Optional, Dict, Any
from urllib.parse import urljoin, urlparse
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import Product, ProductCategory
from src.config.settings import get_settings
from src.services.llm_processor import LLMProcessor

logger = logging.getLogger(__name__)

class ProductScraper:
    """Service for scraping product information from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
        self.session = None
        self.llm_processor = LLMProcessor()
    
    async def scrape_products(self, website_url: str) -> List[Product]:
        """
        Scrape the complete product catalog from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            
        Returns:
            List[Product]: List of all products found
        """
        try:
            # Try to get products from /products.json first (most efficient)
            products = await self._scrape_products_json(website_url)
            if products:
                logger.info(f"Found {len(products)} products via JSON API")
                return products
            
            # Fallback to scraping individual product pages
            logger.info("JSON API not available, falling back to page scraping")
            products = await self._scrape_products_from_pages(website_url)
            return products
            
        except Exception as e:
            logger.error(f"Error scraping products: {str(e)}")
            return []
    
    async def scrape_hero_products(self, website_url: str, driver: webdriver.Chrome) -> List[Product]:
        """
        Scrape hero products from the homepage
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            List[Product]: List of hero products
        """
        try:
            if not driver:
                logger.warning("No webdriver available for hero products")
                return []
            
            hero_products = []
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for hero sections
            hero_selectors = [
                "section[class*='hero']",
                "div[class*='hero']",
                "section[class*='featured']",
                "div[class*='featured']",
                "section[class*='banner']",
                "div[class*='banner']"
            ]
            
            for selector in hero_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        products = self._extract_products_from_element(element, website_url)
                        hero_products.extend(products)
                except Exception as e:
                    logger.debug(f"Error with selector {selector}: {str(e)}")
                    continue
            
            # Also check for product grids on homepage
            product_grid_selectors = [
                "div[class*='product-grid']",
                "div[class*='products']",
                "section[class*='products']",
                "div[class*='collection']"
            ]
            
            for selector in product_grid_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        products = self._extract_products_from_element(element, website_url)
                        hero_products.extend(products)
                except Exception as e:
                    logger.debug(f"Error with product grid selector {selector}: {str(e)}")
                    continue
            
            # Remove duplicates and limit to reasonable number
            unique_products = self._deduplicate_products(hero_products)
            return unique_products[:10]  # Limit to 10 hero products
            
        except Exception as e:
            logger.error(f"Error scraping hero products: {str(e)}")
            return []
    
    async def _scrape_products_json(self, website_url: str) -> List[Product]:
        """Scrape products using Shopify's /products.json endpoint"""
        try:
            # Try multiple JSON endpoints for better coverage
            json_endpoints = [
                "/products.json",
                "/collections/all/products.json",
                "/collections/frontpage/products.json"
            ]
            
            for endpoint in json_endpoints:
                try:
                    products_url = urljoin(website_url, endpoint)
                    logger.info(f"Trying JSON endpoint: {products_url}")
                    
                    async with aiohttp.ClientSession() as session:
                        async with session.get(products_url, timeout=self.settings.request_timeout) as response:
                            if response.status == 200:
                                data = await response.json()
                                products_data = data.get('products', [])
                                
                                if products_data:
                                     logger.info(f"Found {len(products_data)} products via {endpoint}")
                                     products = []
                                     for product_data in products_data:
                                         product = await self._parse_product_json(product_data, website_url)
                                         if product:
                                             products.append(product)
                                     
                                     if products:
                                         return products
                            else:
                                logger.debug(f"{endpoint} returned status {response.status}")
                                
                except Exception as e:
                    logger.debug(f"Error with {endpoint}: {str(e)}")
                    continue
            
            logger.info("No JSON endpoints provided product data")
            return []
                        
        except Exception as e:
            logger.debug(f"Error with products.json: {str(e)}")
            return []
    
    async def _scrape_products_from_pages(self, website_url: str) -> List[Product]:
        """Scrape products by crawling product pages"""
        try:
            # Get product URLs from multiple sources
            product_urls = await self._get_product_urls(website_url)
            
            if not product_urls:
                logger.warning("No product URLs found, trying alternative methods")
                # Try to find products on homepage
                product_urls = await self._find_products_on_homepage(website_url)
            
            logger.info(f"Found {len(product_urls)} product URLs to scrape")
            
            products = []
            # Limit to reasonable number for performance
            max_products = min(len(product_urls), 30)
            
            for i, url in enumerate(product_urls[:max_products]):
                try:
                    logger.info(f"Scraping product {i+1}/{max_products}: {url}")
                    product = await self._scrape_single_product(url)
                    if product:
                        products.append(product)
                        logger.info(f"Successfully scraped: {product.title}")
                    else:
                        logger.debug(f"Failed to scrape product from {url}")
                except Exception as e:
                    logger.debug(f"Error scraping product {url}: {str(e)}")
                    continue
            
            logger.info(f"Successfully scraped {len(products)} products from pages")
            return products
            
        except Exception as e:
            logger.error(f"Error scraping products from pages: {str(e)}")
            return []
    
    async def _get_product_urls(self, website_url: str) -> List[str]:
        """Get list of product URLs from various sources"""
        urls = []
        
        # Try sitemap
        try:
            sitemap_url = urljoin(website_url, "/sitemap.xml")
            async with aiohttp.ClientSession() as session:
                async with session.get(sitemap_url, timeout=self.settings.request_timeout) as response:
                    if response.status == 200:
                        content = await response.text()
                        soup = BeautifulSoup(content, 'xml')
                        for loc in soup.find_all('loc'):
                            if '/products/' in loc.text:
                                urls.append(loc.text)
        except Exception as e:
            logger.debug(f"Error with sitemap: {str(e)}")
        
        # Try collection pages
        try:
            collections_url = urljoin(website_url, "/collections")
            async with aiohttp.ClientSession() as session:
                async with session.get(collections_url, timeout=self.settings.request_timeout) as response:
                    if response.status == 200:
                        content = await response.text()
                        soup = BeautifulSoup(content, 'html.parser')
                        for link in soup.find_all('a', href=True):
                            if '/products/' in link['href']:
                                full_url = urljoin(website_url, link['href'])
                                urls.append(full_url)
        except Exception as e:
            logger.debug(f"Error with collections: {str(e)}")
        
        return list(set(urls))  # Remove duplicates
    
    async def _find_products_on_homepage(self, website_url: str) -> List[str]:
        """Find product URLs on the homepage"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(website_url, timeout=self.settings.request_timeout) as response:
                    if response.status == 200:
                        content = await response.text()
                        soup = BeautifulSoup(content, 'html.parser')
                        
                        product_urls = []
                        
                        # Look for product links
                        for link in soup.find_all('a', href=True):
                            href = link.get('href', '')
                            if '/products/' in href:
                                full_url = urljoin(website_url, href)
                                product_urls.append(full_url)
                        
                        # Also look for collection links that might contain products
                        for link in soup.find_all('a', href=True):
                            href = link.get('href', '')
                            if '/collections/' in href and '/products/' not in href:
                                # This is a collection page, try to get products from it
                                collection_url = urljoin(website_url, href)
                                try:
                                    collection_response = await session.get(collection_url, timeout=10)
                                    if collection_response.status == 200:
                                        collection_content = await collection_response.text()
                                        collection_soup = BeautifulSoup(collection_content, 'html.parser')
                                        
                                        for product_link in collection_soup.find_all('a', href=True):
                                            product_href = product_link.get('href', '')
                                            if '/products/' in product_href:
                                                full_product_url = urljoin(website_url, product_href)
                                                product_urls.append(full_product_url)
                                except Exception as e:
                                    logger.debug(f"Error getting products from collection {collection_url}: {str(e)}")
                                    continue
                        
                        logger.info(f"Found {len(product_urls)} product URLs on homepage")
                        return list(set(product_urls))  # Remove duplicates
                    else:
                        logger.warning(f"Homepage returned status {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Error finding products on homepage: {str(e)}")
            return []
    
    async def _scrape_single_product(self, product_url: str) -> Optional[Product]:
        """Scrape a single product page"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(product_url, timeout=self.settings.request_timeout) as response:
                    if response.status == 200:
                        content = await response.text()
                        soup = BeautifulSoup(content, 'html.parser')
                        
                        # Extract product information with better selectors
                        title = self._extract_text(soup, [
                            'h1[class*="product-title"]',
                            'h1[class*="title"]',
                            'h1[class*="ProductTitle"]',
                            'h1[class*="product__title"]',
                            'h1'
                        ])
                        
                        if not title:
                            logger.debug(f"No title found for product at {product_url}")
                            return None
                        
                        # Extract description with better selectors
                        description = self._extract_text(soup, [
                            'div[class*="description"]',
                            'div[class*="product-description"]',
                            'div[class*="Description"]',
                            'div[class*="product__description"]',
                            'meta[name="description"]',
                            'meta[property="og:description"]'
                        ])
                        
                        # Extract price with better logic
                        price = self._extract_price(soup)
                        
                        # Extract images with better selectors
                        images = self._extract_images(soup, product_url)
                        
                        # Extract tags and category
                        tags = self._extract_tags(soup)
                        category = self._determine_category(title, tags, "")
                        
                        # Extract availability
                        available = self._extract_availability(soup)
                        
                        # Extract currency (default to USD)
                        currency = "USD"
                        
                        logger.info(f"Scraped product: {title} - Price: {price} - Images: {len(images)}")
                        
                        # Create base product
                        product = Product(
                            title=title,
                            description=description,
                            price=price,
                            currency=currency,
                            images=images,
                            category=category,
                            tags=tags,
                            url=product_url,
                            available=available
                        )
                        
                        # Enhance product with LLM
                        try:
                            enhanced_product = await self._enhance_product_with_llm(product)
                            if enhanced_product:
                                return enhanced_product
                        except Exception as e:
                            logger.warning(f"LLM enhancement failed for {title}: {str(e)}")
                        
                        return product
                    else:
                        logger.debug(f"Product page {product_url} returned status {response.status}")
                        
        except Exception as e:
            logger.debug(f"Error scraping single product {product_url}: {str(e)}")
        
        return None
    
    async def _parse_product_json(self, product_data: Dict[str, Any], website_url: str) -> Optional[Product]:
        """Parse product data from JSON response"""
        try:
            title = product_data.get('title', '')
            if not title:
                return None
            
            # Extract description
            description = product_data.get('body_html', '')
            if description:
                # Remove HTML tags
                soup = BeautifulSoup(description, 'html.parser')
                description = soup.get_text().strip()
            
            # Extract price with better logic
            price = None
            currency = "USD"  # Default currency
            variants = product_data.get('variants', [])
            
            if variants:
                # Get the first available variant with a price
                for variant in variants:
                    if variant.get('available', True):  # Check if variant is available
                        price_str = variant.get('price', '0')
                        if price_str and price_str != '0':
                            try:
                                price = float(price_str)
                                break
                            except (ValueError, TypeError):
                                continue
                
                # If no available variant found, use the first one
                if price is None and variants:
                    variant = variants[0]
                    price_str = variant.get('price', '0')
                    try:
                        price = float(price_str) if price_str != '0' else None
                    except (ValueError, TypeError):
                        pass
            
            # Extract images with better handling
            images = []
            for image in product_data.get('images', []):
                if image.get('src'):
                    image_url = image['src']
                    if not image_url.startswith('http'):
                        image_url = 'https:' + image_url
                    images.append(image_url)
            
            # Extract tags
            tags = product_data.get('tags', [])
            if isinstance(tags, str):
                tags = [tag.strip() for tag in tags.split(',') if tag.strip()]
            
            # Extract product type and vendor
            product_type = product_data.get('product_type', '')
            vendor = product_data.get('vendor', '')
            
            # Determine category with better logic
            category = self._determine_category(title, tags, product_type)
            
            # Extract availability
            available = any(variant.get('available', False) for variant in variants) if variants else True
            
            # Extract metafields if available
            metafields = {}
            if product_data.get('metafields'):
                for metafield in product_data['metafields']:
                    key = metafield.get('key', '')
                    value = metafield.get('value', '')
                    if key and value:
                        metafields[key] = value
            
            # Build product URL
            handle = product_data.get('handle', '')
            product_url = urljoin(website_url, f"/products/{handle}") if handle else website_url
            
            logger.info(f"Parsed product: {title} - Price: {price} - Images: {len(images)}")
            
            # Create base product
            product = Product(
                id=str(product_data.get('id', '')),
                title=title,
                description=description,
                price=price,
                currency=currency,
                images=images,
                category=category,
                tags=tags,
                url=product_url,
                available=available,
                variants=variants,
                metafields=metafields
            )
            
            # Enhance product with LLM
            try:
                enhanced_product = await self._enhance_product_with_llm(product)
                if enhanced_product:
                    return enhanced_product
            except Exception as e:
                logger.warning(f"LLM enhancement failed for {title}: {str(e)}")
            
            return product
            
        except Exception as e:
            logger.error(f"Error parsing product JSON: {str(e)}")
            return None
    
    def _extract_products_from_element(self, element, website_url: str) -> List[Product]:
        """Extract products from a DOM element"""
        products = []
        
        try:
            # Look for product links
            product_links = element.find_elements(By.CSS_SELECTOR, "a[href*='/products/']")
            
            for link in product_links:
                try:
                    href = link.get_attribute('href')
                    if href and '/products/' in href:
                        # Extract basic product info
                        title_elem = link.find_element(By.CSS_SELECTOR, "h3, h4, .product-title, .title")
                        title = title_elem.text.strip() if title_elem else "Unknown Product"
                        
                        # Extract price
                        price_elem = link.find_element(By.CSS_SELECTOR, ".price, .product-price, [class*='price']")
                        price = None
                        if price_elem:
                            price_text = price_elem.text.strip()
                            price = self._extract_price_from_text(price_text)
                        
                        # Extract image
                        img_elem = link.find_element(By.CSS_SELECTOR, "img")
                        images = []
                        if img_elem:
                            src = img_elem.get_attribute('src')
                            if src:
                                if not src.startswith('http'):
                                    src = urljoin(website_url, src)
                                images.append(src)
                        
                        product = Product(
                            title=title,
                            price=price,
                            images=images,
                            url=href
                        )
                        products.append(product)
                        
                except Exception as e:
                    logger.debug(f"Error extracting product from link: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error extracting products from element: {str(e)}")
        
        return products
    
    def _extract_text(self, soup: BeautifulSoup, selectors: List[str]) -> Optional[str]:
        """Extract text using multiple selectors"""
        for selector in selectors:
            try:
                element = soup.select_one(selector)
                if element:
                    if selector.startswith('meta'):
                        return element.get('content', '').strip()
                    else:
                        return element.get_text().strip()
            except Exception:
                continue
        return None
    
    def _extract_price(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract price from product page"""
        price_selectors = [
            '.price',
            '.product-price',
            '[class*="price"]',
            '[class*="Price"]',
            '[class*="PriceRange"]',
            '[class*="product__price"]',
            '[class*="ProductPrice"]',
            'span[data-price]',
            'meta[property="product:price:amount"]'
        ]
        
        for selector in price_selectors:
            try:
                if selector.startswith('meta'):
                    element = soup.select_one(selector)
                    if element:
                        price_text = element.get('content', '').strip()
                        if price_text:
                            return self._extract_price_from_text(price_text)
                else:
                    element = soup.select_one(selector)
                    if element:
                        price_text = element.get_text().strip()
                        if price_text:
                            price = self._extract_price_from_text(price_text)
                            if price:
                                return price
            except Exception:
                continue
        
        # Try to find price in structured data (JSON-LD)
        try:
            script_tags = soup.find_all('script', type='application/ld+json')
            for script in script_tags:
                try:
                    data = json.loads(script.string)
                    if isinstance(data, dict) and data.get('@type') == 'Product':
                        price_text = data.get('offers', {}).get('price', '')
                        if price_text:
                            return self._extract_price_from_text(price_text)
                except (json.JSONDecodeError, AttributeError):
                    continue
        except Exception:
            pass
        
        return None
    
    def _extract_price_from_text(self, price_text: str) -> Optional[float]:
        """Extract numeric price from text"""
        try:
            # Clean the price text
            cleaned_text = price_text.strip()
            
            # Remove common currency symbols and text
            cleaned_text = re.sub(r'[^\d.,]', '', cleaned_text)
            
            # Handle different price formats
            # Look for price ranges (e.g., "$10.00 - $20.00")
            if ' - ' in cleaned_text:
                # Take the first price in range
                cleaned_text = cleaned_text.split(' - ')[0]
            
            # Remove commas and extract the number
            price_match = re.search(r'[\d,]+\.?\d*', cleaned_text.replace(',', ''))
            if price_match:
                price_str = price_match.group()
                # Handle cases where price might be in cents
                if len(price_str.split('.')[-1]) == 2 and float(price_str) < 1000:
                    # Likely a price in dollars (e.g., 29.99)
                    return float(price_str)
                elif len(price_str.split('.')[-1]) == 2 and float(price_str) >= 1000:
                    # Likely a price in cents (e.g., 2999.00)
                    return float(price_str) / 100
                else:
                    return float(price_str)
        except (ValueError, TypeError) as e:
            logger.debug(f"Error parsing price '{price_text}': {str(e)}")
        return None
    
    def _extract_images(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        """Extract image URLs from product page"""
        images = []
        
        # Look for product images with better selectors
        img_selectors = [
            'img[class*="product"]',
            'img[class*="main"]',
            'img[class*="Product"]',
            'img[class*="featured"]',
            'img[class*="hero"]',
            '.product-image img',
            '.main-image img',
            '.product__image img',
            '.ProductImage img',
            '[class*="product-gallery"] img',
            '[class*="ProductGallery"] img'
        ]
        
        for selector in img_selectors:
            try:
                elements = soup.select(selector)
                for element in elements:
                    src = element.get('src')
                    if src:
                        # Handle relative URLs and data URLs
                        if src.startswith('//'):
                            src = 'https:' + src
                        elif not src.startswith('http'):
                            src = urljoin(base_url, src)
                        
                        # Skip data URLs and small images
                        if not src.startswith('data:') and 'placeholder' not in src.lower():
                            images.append(src)
            except Exception:
                continue
        
        # Also look for images in structured data
        try:
            script_tags = soup.find_all('script', type='application/ld+json')
            for script in script_tags:
                try:
                    data = json.loads(script.string)
                    if isinstance(data, dict) and data.get('@type') == 'Product':
                        product_images = data.get('image', [])
                        if isinstance(product_images, list):
                            for img_url in product_images:
                                if img_url and isinstance(img_url, str):
                                    if not img_url.startswith('http'):
                                        img_url = urljoin(base_url, img_url)
                                    images.append(img_url)
                        elif isinstance(product_images, str):
                            if not product_images.startswith('http'):
                                product_images = urljoin(base_url, product_images)
                            images.append(product_images)
                except (json.JSONDecodeError, AttributeError):
                    continue
        except Exception:
            pass
        
        # Remove duplicates and filter out invalid URLs
        unique_images = []
        seen = set()
        for img in images:
            if img and img not in seen and 'placeholder' not in img.lower():
                seen.add(img)
                unique_images.append(img)
        
        return unique_images
    
    async def _enhance_product_with_llm(self, product: Product) -> Optional[Product]:
        """Enhance product data using LLM"""
        try:
            if not self.llm_processor:
                return product
            
            # Prepare context for LLM
            context = f"""
            Product Title: {product.title}
            Description: {product.description or 'No description available'}
            Price: {product.price} {product.currency}
            Current Category: {product.category or 'None'}
            Current Tags: {', '.join(product.tags) if product.tags else 'None'}
            
            Please enhance this product by:
            1. Suggesting an appropriate category from: clothing, electronics, beauty, home, sports, food, other
            2. Adding relevant tags (comma-separated)
            3. Improving the description if it's too short
            4. Suggesting product variants if applicable
            
            Return as JSON:
            {{
                "category": "suggested_category",
                "tags": ["tag1", "tag2", "tag3"],
                "enhanced_description": "improved description",
                "suggested_variants": ["variant1", "variant2"]
            }}
            """
            
            # Get LLM enhancement
            enhanced_data = await self.llm_processor.enhance_product(context)
            
            if enhanced_data:
                # Update product with LLM suggestions
                if enhanced_data.get('category'):
                    product.category = enhanced_data['category']
                
                if enhanced_data.get('tags'):
                    product.tags = enhanced_data['tags']
                
                if enhanced_data.get('enhanced_description') and not product.description:
                    product.description = enhanced_data['enhanced_description']
                
                logger.info(f"LLM enhanced product: {product.title} - Category: {product.category} - Tags: {len(product.tags)}")
            
            return product
            
        except Exception as e:
            logger.error(f"Error enhancing product with LLM: {str(e)}")
            return product
    
    def _extract_tags(self, soup: BeautifulSoup) -> List[str]:
        """Extract product tags from page"""
        tags = []
        try:
            # Look for tag elements
            tag_selectors = [
                'span[class*="tag"]',
                'a[class*="tag"]',
                'div[class*="tag"]',
                'meta[name="keywords"]'
            ]
            
            for selector in tag_selectors:
                try:
                    if selector.startswith('meta'):
                        element = soup.select_one(selector)
                        if element:
                            content = element.get('content', '')
                            if content:
                                tags.extend([tag.strip() for tag in content.split(',') if tag.strip()])
                    else:
                        elements = soup.select(selector)
                        for element in elements:
                            tag_text = element.get_text().strip()
                            if tag_text:
                                tags.append(tag_text)
                except Exception:
                    continue
            
            return list(set(tags))  # Remove duplicates
        except Exception as e:
            logger.debug(f"Error extracting tags: {str(e)}")
            return []
    
    def _extract_availability(self, soup: BeautifulSoup) -> bool:
        """Extract product availability from page"""
        try:
            # Look for availability indicators
            availability_selectors = [
                '[class*="available"]',
                '[class*="in-stock"]',
                '[class*="out-of-stock"]',
                '[class*="sold-out"]'
            ]
            
            for selector in availability_selectors:
                try:
                    element = soup.select_one(selector)
                    if element:
                        text = element.get_text().lower()
                        if 'out of stock' in text or 'sold out' in text or 'unavailable' in text:
                            return False
                        elif 'in stock' in text or 'available' in text:
                            return True
                except Exception:
                    continue
            
            # Default to available if no indicators found
            return True
        except Exception as e:
            logger.debug(f"Error extracting availability: {str(e)}")
            return True
    
    def _determine_category(self, title: str, tags: List[str], product_type: str) -> str:
        """Determine product category based on title, tags, and type"""
        text = f"{title} {' '.join(tags)} {product_type}".lower()
        
        # More comprehensive category detection
        if any(word in text for word in ['shirt', 'dress', 'pants', 'jeans', 'jacket', 'sweater', 'coord', 'co-ord', 'kurta', 'dupatta', 'saree', 'lehenga', 'gown', 'top', 'blouse', 't-shirt', 'tshirt']):
            return "clothing"
        elif any(word in text for word in ['phone', 'laptop', 'computer', 'camera', 'headphones', 'mobile', 'tablet', 'gadget', 'electronic']):
            return "electronics"
        elif any(word in text for word in ['makeup', 'skincare', 'hair', 'beauty', 'cosmetic', 'perfume', 'fragrance', 'lotion', 'cream']):
            return "beauty"
        elif any(word in text for word in ['furniture', 'decor', 'kitchen', 'home', 'garden', 'bedroom', 'living', 'dining', 'office']):
            return "home"
        elif any(word in text for word in ['sports', 'fitness', 'gym', 'running', 'yoga', 'athletic', 'workout', 'training', 'exercise']):
            return "sports"
        elif any(word in text for word in ['food', 'snack', 'beverage', 'drink', 'organic', 'healthy', 'nutrition', 'supplement']):
            return "food"
        elif any(word in text for word in ['book', 'magazine', 'journal', 'notebook', 'stationery', 'pen', 'pencil']):
            return "books"
        elif any(word in text for word in ['toy', 'game', 'puzzle', 'educational', 'children', 'kids', 'baby']):
            return "toys"
        else:
            return "other"
    
    def _deduplicate_products(self, products: List[Product]) -> List[Product]:
        """Remove duplicate products based on title and URL"""
        seen = set()
        unique_products = []
        
        for product in products:
            key = (product.title.lower(), product.url)
            if key not in seen:
                seen.add(key)
                unique_products.append(product)
        
        return unique_products
