import logging
import re
from typing import Optional
from urllib.parse import urljoin
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from src.models.shopify_insights import BrandContext
from src.config.settings import get_settings

logger = logging.getLogger(__name__)

class BrandScraper:
    """Service for scraping brand context and information from Shopify stores"""
    
    def __init__(self):
        self.settings = get_settings()
    
    async def scrape_brand_context(self, website_url: str, driver: webdriver.Chrome) -> Optional[BrandContext]:
        """
        Scrape brand context and information from a Shopify store
        
        Args:
            website_url: Base URL of the Shopify store
            driver: Selenium webdriver instance
            
        Returns:
            BrandContext: Brand context information found
        """
        try:
            # Try to find brand information using multiple methods
            brand_context = await self._scrape_from_homepage(website_url, driver)
            if not brand_context:
                brand_context = await self._scrape_from_about_page(website_url, driver)
            if not brand_context:
                brand_context = await self._scrape_from_meta_tags(website_url, driver)
            
            return brand_context
            
        except Exception as e:
            logger.error(f"Error scraping brand context: {str(e)}")
            return None
    
    async def _scrape_from_homepage(self, website_url: str, driver: webdriver.Chrome) -> Optional[BrandContext]:
        """Scrape brand information from homepage"""
        try:
            if not driver:
                return None
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for brand information sections
            brand_selectors = [
                '[class*="hero"]',
                '[class*="banner"]',
                '[class*="intro"]',
                '[class*="welcome"]',
                '[class*="about"]',
                '[class*="story"]',
                'header',
                'main'
            ]
            
            for selector in brand_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        brand_context = self._extract_brand_from_element(element, website_url)
                        if brand_context and brand_context.name:
                            return brand_context
                except Exception as e:
                    logger.debug(f"Error with brand selector {selector}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping brand context from homepage: {str(e)}")
        
        return None
    
    async def _scrape_from_about_page(self, website_url: str, driver: webdriver.Chrome) -> Optional[BrandContext]:
        """Scrape brand information from about page"""
        try:
            # Try to find about page
            about_patterns = [
                '/about',
                '/about-us',
                '/our-story',
                '/our-mission',
                '/who-we-are',
                '/pages/about',
                '/pages/about-us',
                '/pages/our-story'
            ]
            
            for pattern in about_patterns:
                try:
                    about_url = urljoin(website_url, pattern)
                    if await self._url_exists(about_url):
                        brand_context = await self._scrape_brand_from_page(about_url, driver)
                        if brand_context:
                            return brand_context
                except Exception as e:
                    logger.debug(f"Error with about pattern {pattern}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error scraping brand context from about page: {str(e)}")
        
        return None
    
    async def _scrape_from_meta_tags(self, website_url: str, driver: webdriver.Chrome) -> Optional[BrandContext]:
        """Scrape brand information from meta tags"""
        try:
            if not driver:
                return None
            
            # Navigate to homepage
            driver.get(website_url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "head"))
            )
            
            # Extract brand name from title
            title = driver.title.strip()
            if title:
                # Extract brand name from title (usually before dash or pipe)
                brand_name = self._extract_brand_name_from_title(title)
                
                if brand_name:
                    return BrandContext(
                        name=brand_name,
                        description=title
                    )
            
        except Exception as e:
            logger.debug(f"Error scraping brand context from meta tags: {str(e)}")
        
        return None
    
    async def _scrape_brand_from_page(self, url: str, driver: webdriver.Chrome) -> Optional[BrandContext]:
        """Scrape brand information from a specific page"""
        try:
            # Try using aiohttp first
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, timeout=self.settings.request_timeout) as response:
                        if response.status == 200:
                            content = await response.text()
                            brand_context = self._extract_brand_from_html(content, url)
                            if brand_context:
                                return brand_context
            except Exception as e:
                logger.debug(f"aiohttp failed for {url}, trying Selenium: {str(e)}")
            
            # Fallback to Selenium
            if driver:
                driver.get(url)
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                content = driver.page_source
                brand_context = self._extract_brand_from_html(content, url)
                if brand_context:
                    return brand_context
            
        except Exception as e:
            logger.debug(f"Error scraping brand context from page {url}: {str(e)}")
        
        return None
    
    def _extract_brand_from_element(self, element, website_url: str) -> Optional[BrandContext]:
        """Extract brand information from a DOM element"""
        try:
            # Get text content
            text = element.text.strip()
            
            # Extract brand name
            brand_name = self._extract_brand_name_from_text(text)
            
            # Extract description
            description = self._extract_description_from_text(text)
            
            # Extract about information
            about = self._extract_about_from_text(text)
            
            # Extract mission and vision
            mission = self._extract_mission_from_text(text)
            vision = self._extract_vision_from_text(text)
            
            # Extract founded year
            founded_year = self._extract_founded_year_from_text(text)
            
            # Extract headquarters
            headquarters = self._extract_headquarters_from_text(text)
            
            # Extract industry
            industry = self._extract_industry_from_text(text)
            
            if brand_name:
                return BrandContext(
                    name=brand_name,
                    description=description,
                    about=about,
                    mission=mission,
                    vision=vision,
                    founded_year=founded_year,
                    headquarters=headquarters,
                    industry=industry
                )
            
        except Exception as e:
            logger.debug(f"Error extracting brand context from element: {str(e)}")
        
        return None
    
    def _extract_brand_from_html(self, html_content: str, url: str) -> Optional[BrandContext]:
        """Extract brand information from HTML content"""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Extract brand name from title
            title = soup.find('title')
            brand_name = None
            if title:
                brand_name = self._extract_brand_name_from_title(title.get_text())
            
            # Extract description from meta tags
            description = None
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            if meta_desc:
                description = meta_desc.get('content', '').strip()
            
            # Get main content
            main_content = soup.find('main') or soup.find('body')
            if main_content:
                text = main_content.get_text()
                
                # Extract additional information
                about = self._extract_about_from_text(text)
                mission = self._extract_mission_from_text(text)
                vision = self._extract_vision_from_text(text)
                founded_year = self._extract_founded_year_from_text(text)
                headquarters = self._extract_headquarters_from_text(text)
                industry = self._extract_industry_from_text(text)
                
                if brand_name:
                    return BrandContext(
                        name=brand_name,
                        description=description,
                        about=about,
                        mission=mission,
                        vision=vision,
                        founded_year=founded_year,
                        headquarters=headquarters,
                        industry=industry
                    )
            
        except Exception as e:
            logger.debug(f"Error extracting brand context from HTML: {str(e)}")
        
        return None
    
    def _extract_brand_name_from_title(self, title: str) -> Optional[str]:
        """Extract brand name from page title"""
        try:
            if not title:
                return None
            
            # Common separators in titles
            separators = [' - ', ' | ', ' :: ', ' – ', ' — ']
            
            for separator in separators:
                if separator in title:
                    parts = title.split(separator)
                    if parts:
                        # Usually the brand name is the first part
                        brand_name = parts[0].strip()
                        if brand_name and len(brand_name) > 2:
                            return brand_name
            
            # If no separator found, return the title if it's reasonable
            if title and len(title) < 100:
                return title.strip()
            
        except Exception as e:
            logger.debug(f"Error extracting brand name from title: {str(e)}")
        
        return None
    
    def _extract_brand_name_from_text(self, text: str) -> Optional[str]:
        """Extract brand name from text content"""
        try:
            if not text:
                return None
            
            # Look for common brand name patterns
            brand_patterns = [
                r'(?:Welcome to|About|Meet)\s+([A-Z][a-zA-Z\s&]+?)(?:\s|\.|,|$)',
                r'([A-Z][a-zA-Z\s&]+?)\s+(?:is|was|has been|has)\s+',
                r'([A-Z][a-zA-Z\s&]+?)\s+(?:brand|company|business|store)',
                r'Founded\s+(?:in\s+)?\d{4}\s+(?:by\s+)?([A-Z][a-zA-Z\s&]+?)(?:\s|\.|,|$)'
            ]
            
            for pattern in brand_patterns:
                matches = re.findall(pattern, text)
                if matches:
                    brand_name = matches[0].strip()
                    if brand_name and len(brand_name) > 2 and len(brand_name) < 100:
                        return brand_name
            
        except Exception as e:
            logger.debug(f"Error extracting brand name from text: {str(e)}")
        
        return None
    
    def _extract_description_from_text(self, text: str) -> Optional[str]:
        """Extract brand description from text"""
        try:
            if not text:
                return None
            
            # Look for description patterns
            desc_patterns = [
                r'(?:We are|We\'re|We)\s+([^.!?]+[.!?])',
                r'(?:Our mission is|Our goal is|We strive to)\s+([^.!?]+[.!?])',
                r'(?:Founded|Established|Started)\s+[^.!?]*?([^.!?]+[.!?])'
            ]
            
            for pattern in desc_patterns:
                matches = re.findall(pattern, text)
                if matches:
                    description = matches[0].strip()
                    if description and len(description) > 20 and len(description) < 500:
                        return description
            
        except Exception as e:
            logger.debug(f"Error extracting description from text: {str(e)}")
        
        return None
    
    def _extract_about_from_text(self, text: str) -> Optional[str]:
        """Extract about information from text"""
        try:
            if not text:
                return None
            
            # Look for about sections
            about_patterns = [
                r'(?:About|About Us|Our Story|Who We Are)[:.\s]+([^.!?]+[.!?])',
                r'(?:We are|We\'re)\s+([^.!?]+[.!?])',
                r'(?:Founded|Established|Started)\s+[^.!?]*?([^.!?]+[.!?])'
            ]
            
            for pattern in about_patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                if matches:
                    about = matches[0].strip()
                    if about and len(about) > 20 and len(about) < 1000:
                        return about
            
        except Exception as e:
            logger.debug(f"Error extracting about from text: {str(e)}")
        
        return None
    
    def _extract_mission_from_text(self, text: str) -> Optional[str]:
        """Extract mission statement from text"""
        try:
            if not text:
                return None
            
            # Look for mission statements
            mission_patterns = [
                r'(?:Our mission is|Our mission|Mission)[:.\s]+([^.!?]+[.!?])',
                r'(?:We strive to|We aim to|We work to)\s+([^.!?]+[.!?])',
                r'(?:Dedicated to|Committed to)\s+([^.!?]+[.!?])'
            ]
            
            for pattern in mission_patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                if matches:
                    mission = matches[0].strip()
                    if mission and len(mission) > 20 and len(mission) < 500:
                        return mission
            
        except Exception as e:
            logger.debug(f"Error extracting mission from text: {str(e)}")
        
        return None
    
    def _extract_vision_from_text(self, text: str) -> Optional[str]:
        """Extract vision statement from text"""
        try:
            if not text:
                return None
            
            # Look for vision statements
            vision_patterns = [
                r'(?:Our vision is|Our vision|Vision)[:.\s]+([^.!?]+[.!?])',
                r'(?:We envision|We see|We believe)\s+([^.!?]+[.!?])',
                r'(?:Looking forward|Looking ahead)\s+([^.!?]+[.!?])'
            ]
            
            for pattern in vision_patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                if matches:
                    vision = matches[0].strip()
                    if vision and len(vision) > 20 and len(vision) < 500:
                        return vision
            
        except Exception as e:
            logger.debug(f"Error extracting vision from text: {str(e)}")
        
        return None
    
    def _extract_founded_year_from_text(self, text: str) -> Optional[int]:
        """Extract founded year from text"""
        try:
            if not text:
                return None
            
            # Look for year patterns
            year_patterns = [
                r'(?:Founded|Established|Started|Founded in|Established in|Started in)\s+(\d{4})',
                r'(\d{4})\s+(?:Founded|Established|Started)',
                r'(?:Since|From)\s+(\d{4})',
                r'(\d{4})\s+(?:years|year)'
            ]
            
            for pattern in year_patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                if matches:
                    year = int(matches[0])
                    if 1800 <= year <= 2030:  # Reasonable year range
                        return year
            
        except Exception as e:
            logger.debug(f"Error extracting founded year from text: {str(e)}")
        
        return None
    
    def _extract_headquarters_from_text(self, text: str) -> Optional[str]:
        """Extract headquarters location from text"""
        try:
            if not text:
                return None
            
            # Look for location patterns
            location_patterns = [
                r'(?:Headquartered|Based|Located|Headquarters)[:.\s]+([^.!?]+[.!?])',
                r'(?:in|at)\s+([A-Z][a-zA-Z\s,]+(?:City|Town|State|Country|Province))',
                r'(?:from|out of)\s+([A-Z][a-zA-Z\s,]+(?:City|Town|State|Country|Province))'
            ]
            
            for pattern in location_patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                if matches:
                    location = matches[0].strip()
                    if location and len(location) > 5 and len(location) < 200:
                        return location
            
        except Exception as e:
            logger.debug(f"Error extracting headquarters from text: {str(e)}")
        
        return None
    
    def _extract_industry_from_text(self, text: str) -> Optional[str]:
        """Extract industry information from text"""
        try:
            if not text:
                return None
            
            # Common industry keywords
            industry_keywords = [
                'fashion', 'clothing', 'apparel', 'beauty', 'cosmetics', 'skincare',
                'electronics', 'technology', 'computers', 'phones', 'gadgets',
                'home', 'furniture', 'decor', 'kitchen', 'garden',
                'sports', 'fitness', 'outdoor', 'athletic',
                'food', 'beverage', 'restaurant', 'cafe', 'bakery',
                'jewelry', 'accessories', 'watches', 'bags',
                'toys', 'games', 'entertainment', 'books',
                'automotive', 'cars', 'vehicles', 'parts'
            ]
            
            text_lower = text.lower()
            for keyword in industry_keywords:
                if keyword in text_lower:
                    return keyword.title()
            
        except Exception as e:
            logger.debug(f"Error extracting industry from text: {str(e)}")
        
        return None
    
    async def _url_exists(self, url: str) -> bool:
        """Check if a URL exists and is accessible"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=self.settings.request_timeout) as response:
                    return response.status == 200
        except Exception:
            return False
