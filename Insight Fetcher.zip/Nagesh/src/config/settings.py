import os
from typing import Optional
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Settings(BaseSettings):
    """Application settings configuration"""
    
    # API Configuration
    api_title: str = "Shopify Store Insights Fetcher"
    api_version: str = "1.0.0"
    debug: bool = False
    
    # Database Configuration
    database_url: Optional[str] = os.getenv("DATABASE_URL", "mysql://root:Qwerty%40123@localhost/shopify_insights")
    
    # OpenAI Configuration (for LLM processing)
    openai_api_key: Optional[str] = os.getenv("OPENAI_API_KEY")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")
    
    # Scraping Configuration
    request_timeout: int = int(os.getenv("REQUEST_TIMEOUT", "30"))
    max_retries: int = int(os.getenv("MAX_RETRIES", "3"))
    delay_between_requests: float = float(os.getenv("DELAY_BETWEEN_REQUESTS", "1.0"))
    
    # Selenium Configuration
    headless_browser: bool = os.getenv("HEADLESS_BROWSER", "true").lower() == "true"
    browser_timeout: int = int(os.getenv("BROWSER_TIMEOUT", "30"))
    
    # Rate Limiting
    requests_per_minute: int = int(os.getenv("REQUESTS_PER_MINUTE", "60"))
    
    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "allow"

def get_settings() -> Settings:
    """Get application settings instance"""
    return Settings()

# Global settings instance
settings = get_settings()
