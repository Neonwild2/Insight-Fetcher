from pydantic import BaseModel, Field, HttpUrl
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class ProductCategory(str, Enum):
    """Product category enumeration"""
    CLOTHING = "clothing"
    ELECTRONICS = "electronics"
    BEAUTY = "beauty"
    HOME = "home"
    SPORTS = "sports"
    FOOD = "food"
    OTHER = "other"
    # Add more flexible categories for scraped data
    COORD_SET = "coord_set"
    SHIRT = "shirt"
    PANT = "pant"
    DUPATTA = "dupatta"
    KURTA = "kurta"
    FASHION = "fashion"
    APPAREL = "apparel"

class Product(BaseModel):
    """Product information model"""
    id: Optional[str] = None
    title: str
    description: Optional[str] = None
    price: Optional[float] = None
    currency: Optional[str] = "USD"
    images: List[str] = Field(default_factory=list)
    category: Optional[str] = None  # Make category more flexible
    tags: List[str] = Field(default_factory=list)
    url: Optional[str] = None
    available: Optional[bool] = True
    variants: Optional[Dict[str, Any]] = None  # Allow dict or None
    metafields: Dict[str, Any] = Field(default_factory=dict)

class SocialHandle(BaseModel):
    """Social media handle information"""
    platform: str
    handle: Optional[str] = None  # Make handle optional
    url: Optional[str] = None
    followers: Optional[int] = None

class ContactInfo(BaseModel):
    """Contact information model"""
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    contact_form_url: Optional[str] = None

class Policy(BaseModel):
    """Policy information model"""
    title: str
    content: str
    url: Optional[str] = None
    last_updated: Optional[datetime] = None

class FAQ(BaseModel):
    """FAQ item model"""
    question: str
    answer: str
    category: Optional[str] = None

class ImportantLink(BaseModel):
    """Important link model"""
    title: str
    url: str
    description: Optional[str] = None
    category: Optional[str] = None  # Add category field

class BrandContext(BaseModel):
    """Brand context and information"""
    name: str
    description: Optional[str] = None
    about: Optional[str] = None
    mission: Optional[str] = None
    vision: Optional[str] = None
    founded_year: Optional[int] = None
    headquarters: Optional[str] = None
    industry: Optional[str] = None

class ShopifyInsightsResponse(BaseModel):
    """Main response model for Shopify insights"""
    store_url: str
    timestamp: datetime = Field(default_factory=datetime.now)
    success: bool = True
    processing_time: Optional[float] = None  # Add processing time field
    
    # Core insights
    product_catalog: List[Product] = Field(default_factory=list)
    hero_products: List[Product] = Field(default_factory=list)
    
    # Policies
    privacy_policy: Optional[Policy] = None
    return_policy: Optional[Policy] = None
    refund_policy: Optional[Policy] = None
    
    # FAQs
    faqs: List[FAQ] = Field(default_factory=list)
    
    # Social and contact
    social_handles: List[SocialHandle] = Field(default_factory=list)
    contact_info: Optional[ContactInfo] = None
    
    # Brand information
    brand_context: Optional[BrandContext] = None
    
    # Important links
    important_links: List[ImportantLink] = Field(default_factory=list)
    
    # Additional insights
    additional_insights: Dict[str, Any] = Field(default_factory=dict)
    
    # Metadata
    total_products: int = 0
    total_faqs: int = 0
    processing_time: Optional[float] = None

class ErrorResponse(BaseModel):
    """Error response model"""
    error: str
    detail: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    status_code: int

class CompetitorAnalysis(BaseModel):
    """Competitor analysis model"""
    competitor_url: str
    competitor_name: str
    insights: ShopifyInsightsResponse
    similarity_score: Optional[float] = None
    analysis_date: datetime = Field(default_factory=datetime.now)

class ExtendedInsightsResponse(BaseModel):
    """Extended response with competitor analysis"""
    main_store: ShopifyInsightsResponse
    competitors: List[CompetitorAnalysis] = Field(default_factory=list)
    analysis_summary: Optional[str] = None
