from sqlalchemy import Column, Integer, String, Text, DateTime, Float, Boolean, JSON, ForeignKey, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class Store(Base):
    """Store information table"""
    __tablename__ = 'stores'
    
    id = Column(Integer, primary_key=True, index=True)
    store_url = Column(String(500), unique=True, index=True, nullable=False)
    store_name = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    insights = relationship("StoreInsights", back_populates="store", cascade="all, delete-orphan")
    products = relationship("Product", back_populates="store", cascade="all, delete-orphan")
    competitors = relationship("Competitor", back_populates="store", cascade="all, delete-orphan")

class StoreInsights(Base):
    """Store insights table"""
    __tablename__ = 'store_insights'
    
    id = Column(Integer, primary_key=True, index=True)
    store_id = Column(Integer, ForeignKey('stores.id'), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    success = Column(Boolean, default=True)
    processing_time = Column(Float)
    
    # Brand context
    brand_name = Column(String(255))
    brand_description = Column(Text)
    brand_about = Column(Text)
    brand_mission = Column(Text)
    brand_vision = Column(Text)
    brand_founded_year = Column(Integer)
    brand_headquarters = Column(String(500))
    brand_industry = Column(String(100))
    
    # Contact info
    contact_email = Column(String(255))
    contact_phone = Column(String(100))
    contact_address = Column(Text)
    contact_form_url = Column(String(500))
    
    # Policies
    privacy_policy_title = Column(String(255))
    privacy_policy_content = Column(Text)
    privacy_policy_url = Column(String(500))
    
    return_policy_title = Column(String(255))
    return_policy_content = Column(Text)
    return_policy_url = Column(String(500))
    
    refund_policy_title = Column(String(255))
    refund_policy_content = Column(Text)
    refund_policy_url = Column(String(500))
    
    # Metadata
    total_products = Column(Integer, default=0)
    total_faqs = Column(Integer, default=0)
    
    # Relationships
    store = relationship("Store", back_populates="insights")
    faqs = relationship("FAQ", back_populates="insights", cascade="all, delete-orphan")
    social_handles = relationship("SocialHandle", back_populates="insights", cascade="all, delete-orphan")
    important_links = relationship("ImportantLink", back_populates="insights", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_store_insights_store_id', 'store_id'),
        Index('idx_store_insights_timestamp', 'timestamp'),
    )

class Product(Base):
    """Product information table"""
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True, index=True)
    store_id = Column(Integer, ForeignKey('stores.id'), nullable=False)
    product_id = Column(String(100))
    title = Column(String(500), nullable=False)
    description = Column(Text)
    price = Column(Float)
    currency = Column(String(10), default='USD')
    category = Column(String(100))
    tags = Column(JSON)  # Store as JSON array
    url = Column(String(500))
    available = Column(Boolean, default=True)
    variants = Column(JSON)  # Store as JSON
    metafields = Column(JSON)  # Store as JSON
    images = Column(JSON)  # Store as JSON array
    is_hero_product = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    store = relationship("Store", back_populates="products")
    
    # Indexes
    __table_args__ = (
        Index('idx_products_store_id', 'store_id'),
        Index('idx_products_category', 'category'),
        Index('idx_products_title', 'title'),
    )

class FAQ(Base):
    """FAQ information table"""
    __tablename__ = 'faqs'
    
    id = Column(Integer, primary_key=True, index=True)
    insights_id = Column(Integer, ForeignKey('store_insights.id'), nullable=False)
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=False)
    category = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    insights = relationship("StoreInsights", back_populates="faqs")
    
    # Indexes
    __table_args__ = (
        Index('idx_faqs_insights_id', 'insights_id'),
        Index('idx_faqs_category', 'category'),
    )

class SocialHandle(Base):
    """Social media handles table"""
    __tablename__ = 'social_handles'
    
    id = Column(Integer, primary_key=True, index=True)
    insights_id = Column(Integer, ForeignKey('store_insights.id'), nullable=False)
    platform = Column(String(100), nullable=False)
    handle = Column(String(255), nullable=False)
    url = Column(String(500))
    followers = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    insights = relationship("StoreInsights", back_populates="social_handles")
    
    # Indexes
    __table_args__ = (
        Index('idx_social_handles_insights_id', 'insights_id'),
        Index('idx_social_handles_platform', 'platform'),
    )

class ImportantLink(Base):
    """Important links table"""
    __tablename__ = 'important_links'
    
    id = Column(Integer, primary_key=True, index=True)
    insights_id = Column(Integer, ForeignKey('store_insights.id'), nullable=False)
    title = Column(String(255), nullable=False)
    url = Column(String(500), nullable=False)
    description = Column(Text)
    link_type = Column(String(100))  # e.g., 'contact', 'blog', 'about'
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    insights = relationship("StoreInsights", back_populates="important_links")
    
    # Indexes
    __table_args__ = (
        Index('idx_important_links_insights_id', 'insights_id'),
        Index('idx_important_links_type', 'link_type'),
    )

class Competitor(Base):
    """Competitor information table"""
    __tablename__ = 'competitors'
    
    id = Column(Integer, primary_key=True, index=True)
    store_id = Column(Integer, ForeignKey('stores.id'), nullable=False)
    competitor_url = Column(String(500), nullable=False)
    competitor_name = Column(String(255))
    similarity_score = Column(Float)
    analysis_date = Column(DateTime, default=datetime.utcnow)
    
    # Store competitor insights as JSON for simplicity
    competitor_insights = Column(JSON)
    
    # Relationships
    store = relationship("Store", back_populates="competitors")
    
    # Indexes
    __table_args__ = (
        Index('idx_competitors_store_id', 'store_id'),
        Index('idx_competitors_url', 'competitor_url'),
    )

class AnalysisLog(Base):
    """Analysis execution log table"""
    __tablename__ = 'analysis_logs'
    
    id = Column(Integer, primary_key=True, index=True)
    store_url = Column(String(500), nullable=False)
    analysis_type = Column(String(100))  # 'initial', 'competitor', 'update'
    status = Column(String(50))  # 'success', 'failed', 'partial'
    error_message = Column(Text)
    processing_time = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Indexes
    __table_args__ = (
        Index('idx_analysis_logs_store_url', 'store_url'),
        Index('idx_analysis_logs_status', 'status'),
        Index('idx_analysis_logs_created_at', 'created_at'),
    )
