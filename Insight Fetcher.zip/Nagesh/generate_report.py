#!/usr/bin/env python3
"""
HTML Report Generator - Create beautiful reports from scraped data
"""

import mysql.connector
from datetime import datetime
import json
import os

def connect_database():
    """Connect to MySQL database"""
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Qwerty@123",
            database="shopify_insights"
        )
        return connection
    except Exception as e:
        print(f"❌ Database connection failed: {str(e)}")
        return None

def get_store_data(store_id):
    """Get all data for a specific store"""
    
    connection = connect_database()
    if not connection:
        return None
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Get store info
        cursor.execute("SELECT * FROM stores WHERE id = %s", (store_id,))
        store = cursor.fetchone()
        
        if not store:
            return None
        
        # Get products
        cursor.execute("SELECT * FROM products WHERE store_id = %s ORDER BY title", (store_id,))
        products = cursor.fetchall()
        
        # Get FAQs
        cursor.execute("""
            SELECT f.* FROM faqs f
            JOIN store_insights si ON f.insights_id = si.id
            WHERE si.store_id = %s
        """, (store_id,))
        faqs = cursor.fetchall()
        
        # Get social handles
        cursor.execute("""
            SELECT sh.* FROM social_handles sh
            JOIN store_insights si ON sh.insights_id = si.id
            WHERE si.store_id = %s
        """, (store_id,))
        social = cursor.fetchall()
        
        # Get important links
        cursor.execute("""
            SELECT il.* FROM important_links il
            JOIN store_insights si ON il.insights_id = si.id
            WHERE si.store_id = %s
        """, (store_id,))
        links = cursor.fetchall()
        
        # Get store insights
        cursor.execute("SELECT * FROM store_insights WHERE store_id = %s ORDER BY timestamp DESC LIMIT 1", (store_id,))
        insights = cursor.fetchone()
        
        return {
            'store': store,
            'products': products,
            'faqs': faqs,
            'social_handles': social,
            'important_links': links,
            'insights': insights
        }
        
    except Exception as e:
        print(f"❌ Error getting store data: {str(e)}")
        return None
    finally:
        connection.close()

def generate_html_report(store_data, filename=None):
    """Generate beautiful HTML report"""
    
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        store_name = store_data['store']['store_name'].replace(' ', '_')
        filename = f"report_{store_name}_{timestamp}.html"
    
    # HTML template
    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopify Store Insights - {store_data['store']['store_name']}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}
        
        .header {{
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }}
        
        .header h1 {{
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .header p {{
            color: #666;
            font-size: 1.2em;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .stat-card {{
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }}
        
        .stat-card:hover {{
            transform: translateY(-5px);
        }}
        
        .stat-number {{
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }}
        
        .stat-label {{
            color: #666;
            font-size: 1.1em;
        }}
        
        .section {{
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        
        .section h2 {{
            color: #667eea;
            font-size: 1.8em;
            margin-bottom: 20px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }}
        
        .product-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }}
        
        .product-card {{
            border: 1px solid #eee;
            border-radius: 10px;
            padding: 20px;
            transition: transform 0.3s ease;
        }}
        
        .product-card:hover {{
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }}
        
        .product-title {{
            font-size: 1.2em;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }}
        
        .product-price {{
            font-size: 1.1em;
            color: #667eea;
            font-weight: bold;
        }}
        
        .faq-item {{
            border-left: 4px solid #667eea;
            padding-left: 20px;
            margin-bottom: 20px;
        }}
        
        .faq-question {{
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }}
        
        .faq-answer {{
            color: #666;
            line-height: 1.6;
        }}
        
        .social-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }}
        
        .social-card {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }}
        
        .social-platform {{
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }}
        
        .social-url {{
            color: #666;
            word-break: break-all;
        }}
        
        .link-list {{
            list-style: none;
        }}
        
        .link-list li {{
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }}
        
        .link-list li:last-child {{
            border-bottom: none;
        }}
        
        .link-title {{
            font-weight: bold;
            color: #333;
        }}
        
        .link-url {{
            color: #667eea;
            text-decoration: none;
        }}
        
        .link-url:hover {{
            text-decoration: underline;
        }}
        
        .footer {{
            text-align: center;
            color: white;
            padding: 20px;
            margin-top: 30px;
        }}
        
        @media (max-width: 768px) {{
            .stats-grid {{
                grid-template-columns: 1fr;
            }}
            
            .product-grid {{
                grid-template-columns: 1fr;
            }}
            
            .social-grid {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏪 {store_data['store']['store_name']}</h1>
            <p>Comprehensive Shopify Store Insights Report</p>
            <p><strong>Generated on:</strong> {datetime.now().strftime('%B %d, %Y at %I:%M %p')}</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number">{len(store_data['products'])}</div>
                <div class="stat-label">Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len(store_data['faqs'])}</div>
                <div class="stat-label">FAQs</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len(store_data['social_handles'])}</div>
                <div class="stat-label">Social Platforms</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len(store_data['important_links'])}</div>
                <div class="stat-label">Important Links</div>
            </div>
        </div>
        
        <div class="section">
            <h2>📊 Store Information</h2>
            <p><strong>Store URL:</strong> <a href="{store_data['store']['store_url']}" target="_blank">{store_data['store']['store_url']}</a></p>
            <p><strong>Store Name:</strong> {store_data['store']['store_name']}</p>
            <p><strong>Analysis Date:</strong> {store_data['store']['created_at'].strftime('%B %d, %Y') if store_data['store']['created_at'] else 'N/A'}</p>
        </div>
        
        <div class="section">
            <h2>👕 Products ({len(store_data['products'])})</h2>
            <div class="product-grid">
    """
    
    # Add products
    for product in store_data['products']:
        price = product['price'] if product['price'] else 'N/A'
        currency = product['currency'] if product['currency'] else 'USD'
        html_content += f"""
                <div class="product-card">
                    <div class="product-title">{product['title']}</div>
                    <div class="product-price">{price} {currency}</div>
                    <p style="color: #666; margin-top: 10px;">{product['description'][:100] if product['description'] else 'No description available'}...</p>
                </div>
        """
    
    html_content += """
            </div>
        </div>
    """
    
    # Add FAQs if available
    if store_data['faqs']:
        html_content += f"""
        <div class="section">
            <h2>❓ Frequently Asked Questions ({len(store_data['faqs'])})</h2>
        """
        
        for faq in store_data['faqs']:
            html_content += f"""
            <div class="faq-item">
                <div class="faq-question">Q: {faq['question']}</div>
                <div class="faq-answer">A: {faq['answer']}</div>
            </div>
            """
        
        html_content += """
        </div>
        """
    
    # Add social media
    if store_data['social_handles']:
        html_content += f"""
        <div class="section">
            <h2>📱 Social Media Presence ({len(store_data['social_handles'])})</h2>
            <div class="social-grid">
        """
        
        for social in store_data['social_handles']:
            html_content += f"""
                <div class="social-card">
                    <div class="social-platform">{social['platform'].title()}</div>
                    <a href="{social['url']}" target="_blank" class="social-url">{social['url']}</a>
                </div>
            """
        
        html_content += """
            </div>
        </div>
        """
    
    # Add important links
    if store_data['important_links']:
        html_content += f"""
        <div class="section">
            <h2>🔗 Important Links ({len(store_data['important_links'])})</h2>
            <ul class="link-list">
        """
        
        for link in store_data['important_links']:
            html_content += f"""
                <li>
                    <div class="link-title">{link['title']}</div>
                    <a href="{link['url']}" target="_blank" class="link-url">{link['url']}</a>
                </li>
            """
        
        html_content += """
            </ul>
        </div>
        """
    
    # Close HTML
    html_content += """
        <div class="footer">
            <p>Report generated by Shopify Insights Scraper</p>
            <p>© 2025 - All rights reserved</p>
        </div>
    </div>
</body>
</html>
    """
    
    # Save HTML file
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"✅ HTML report generated: {filename}")
        return filename
        
    except Exception as e:
        print(f"❌ Error generating HTML report: {str(e)}")
        return None

def main():
    """Main function"""
    
    print("📊 HTML REPORT GENERATOR")
    print("=" * 50)
    
    # Show available stores
    connection = connect_database()
    if not connection:
        return
    
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id, store_name, store_url FROM stores ORDER BY created_at DESC")
        stores = cursor.fetchall()
        
        if not stores:
            print("No stores found in database")
            return
        
        print("\n📋 Available stores:")
        for store in stores:
            print(f"{store['id']}. {store['store_name']} - {store['store_url']}")
        
        # Get store selection
        store_id = input("\nEnter store ID to generate report: ").strip()
        
        try:
            store_id = int(store_id)
            store_data = get_store_data(store_id)
            
            if store_data:
                filename = generate_html_report(store_data)
                if filename:
                    print(f"\n🎉 Report generated successfully!")
                    print(f"📁 File: {filename}")
                    print(f"🌐 Open the HTML file in your browser to view the report")
            else:
                print(f"❌ Store with ID {store_id} not found")
                
        except ValueError:
            print("❌ Invalid store ID")
            
    except Exception as e:
        print(f"❌ Error: {str(e)}")
    finally:
        connection.close()

if __name__ == "__main__":
    main()
