#!/usr/bin/env python3
"""
Startup script for Shopify Store Insights Fetcher
"""

import os
import sys
import logging
from pathlib import Path

# Add src to Python path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    """Main startup function"""
    try:
        # Check if .env file exists
        env_file = Path(__file__).parent / ".env"
        if not env_file.exists():
            print("⚠️  Warning: .env file not found. Using default configuration.")
            print("   Create a .env file based on .env.example for custom configuration.")
        
        # Import and run the main application
        from main import app
        import uvicorn
        
        print("🚀 Starting Shopify Store Insights Fetcher...")
        print("📖 API Documentation: http://localhost:8000/docs")
        print("🔍 Health Check: http://localhost:8000/health")
        print("⏹️  Press Ctrl+C to stop")
        
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info"
        )
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Make sure you have installed all dependencies:")
        print("   pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Startup error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
