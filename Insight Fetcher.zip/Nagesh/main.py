from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl
import uvicorn
from typing import Optional, List
import logging
from datetime import datetime

from src.services.shopify_insights_service import ShopifyInsightsService
from src.services.database_service import DatabaseService
from src.models.shopify_insights import ShopifyInsightsResponse, ErrorResponse
from src.config.settings import get_settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Shopify Store Insights Fetcher",
    description="A comprehensive API to fetch insights from Shopify stores",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
shopify_service = ShopifyInsightsService()
database_service = DatabaseService()

class WebsiteUrlRequest(BaseModel):
    website_url: HttpUrl


@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Shopify Store Insights Fetcher API",
        "version": "1.0.0",
        "endpoints": {
            "/fetch-insights": "POST - Fetch comprehensive insights from a Shopify store",
            "/fetch-insights-fast": "POST - Fetch basic insights quickly (recommended)",
            "/health": "GET - Health check endpoint"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "shopify-insights-fetcher"}

@app.post("/fetch-insights", response_model=ShopifyInsightsResponse)
async def fetch_shopify_insights(request: WebsiteUrlRequest):
    """
    Fetch comprehensive insights from a Shopify store
    
    Args:
        request: WebsiteUrlRequest containing the Shopify store URL
        
    Returns:
        ShopifyInsightsResponse: Structured insights data from the store
        
    Raises:
        HTTPException: 401 if website not found, 500 for internal errors
    """
    try:
        logger.info(f"Fetching insights for: {request.website_url}")
        
        # Fetch insights using the service
        insights = await shopify_service.fetch_store_insights(str(request.website_url))
        
        # Save insights to database
        save_success = await database_service.save_store_insights(insights)
        
        if save_success:
            logger.info(f"Successfully fetched and saved insights for: {request.website_url}")
        else:
            logger.warning(f"Fetched insights but failed to save to database for: {request.website_url}")
        
        return insights
        
    except Exception as e:
        logger.error(f"Error fetching insights for {request.website_url}: {str(e)}")
        
        if "not found" in str(e).lower() or "404" in str(e):
            raise HTTPException(status_code=401, detail="Website not found or inaccessible")
        else:
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.post("/fetch-insights-fast")
async def fetch_shopify_insights_fast(request: WebsiteUrlRequest):
    """
    Fetch basic insights quickly (no AI processing, minimal data)
    
    Args:
        request: WebsiteUrlRequest containing the Shopify store URL
        
    Returns:
        dict: Basic insights data
    """
    try:
        logger.info(f"Fast fetching insights for: {request.website_url}")
        
        # Quick scrape without heavy processing
        website_url = str(request.website_url)
        
        # Basic scraping - just products and essential info
        basic_insights = {
            "store_url": website_url,
            "store_name": website_url.replace("https://", "").replace("http://", "").split(".")[0].title(),
            "product_catalog": [],
            "social_handles": [],
            "important_links": [],
            "processing_time": 0,
            "timestamp": datetime.now().isoformat()
        }
        
        # Quick product scrape (just first few)
        try:
            from src.services.scrapers.product_scraper import ProductScraper
            product_scraper = ProductScraper()
            products = await product_scraper.scrape_products(website_url)
            basic_insights["product_catalog"] = products[:10]  # Only first 10 products
        except Exception as e:
            logger.warning(f"Quick product scrape failed: {str(e)}")
        
        # Quick social media scrape
        try:
            from src.services.scrapers.social_scraper import SocialScraper
            social_scraper = SocialScraper()
            social = await social_scraper.scrape_social_handles(website_url, None)
            basic_insights["social_handles"] = social[:5]  # Only first 5 social platforms
        except Exception as e:
            logger.warning(f"Quick social scrape failed: {str(e)}")
        
        # Quick links scrape
        try:
            from src.services.scrapers.link_scraper import LinkScraper
            link_scraper = LinkScraper()
            links = await link_scraper.scrape_important_links(website_url, None)
            basic_insights["important_links"] = links[:5]  # Only first 5 links
        except Exception as e:
            logger.warning(f"Quick links scrape failed: {str(e)}")
        
        basic_insights["processing_time"] = 0  # Quick mode
        
        logger.info(f"Fast insights completed for: {website_url}")
        return basic_insights
        
    except Exception as e:
        logger.error(f"Error in fast insights for {request.website_url}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Fast scraping error: {str(e)}")

if __name__ == "__main__":
    settings = get_settings()
    try:
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info"
        )
    finally:
        # Cleanup services
        database_service.close()
        shopify_service.close()
