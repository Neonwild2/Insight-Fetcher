import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_root_endpoint():
    """Test the root endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert "Shopify Store Insights Fetcher API" in data["message"]
    assert "endpoints" in data

def test_health_check():
    """Test the health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "shopify-insights-fetcher"

def test_fetch_insights_invalid_url():
    """Test fetch insights with invalid URL"""
    response = client.post("/fetch-insights", json={"website_url": "invalid-url"})
    assert response.status_code == 422  # Validation error

def test_fetch_insights_missing_url():
    """Test fetch insights with missing URL"""
    response = client.post("/fetch-insights", json={})
    assert response.status_code == 422  # Validation error

def test_fetch_insights_valid_url_format():
    """Test fetch insights with valid URL format"""
    response = client.post("/fetch-insights", json={"website_url": "https://example.com"})
    # This will likely fail with 500 since we're not actually scraping, but URL format is valid
    assert response.status_code in [500, 422]  # Either internal error or validation error
